<div align="center">

<pre>
███████╗██████╗ ███████╗ ██████╗████████╗██████╗ ██╗   ██╗███╗   ███╗     ██████╗ ███████╗
██╔════╝██╔══██╗██╔════╝██╔════╝╚══██╔══╝██╔══██╗██║   ██║████╗ ████║    ██╔═══██╗██╔════╝
███████╗██████╔╝█████╗  ██║        ██║   ██████╔╝██║   ██║██╔████╔██║    ██║   ██║███████╗
╚════██║██╔═══╝ ██╔══╝  ██║        ██║   ██╔══██╗██║   ██║██║╚██╔╝██║    ██║   ██║╚════██║
███████║██║     ███████╗╚██████╗   ██║   ██║  ██║╚██████╔╝██║ ╚═╝ ██║    ╚██████╔╝███████║
╚══════╝╚═╝     ╚══════╝ ╚═════╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝ ╚═╝     ╚═╝     ╚═════╝ ╚══════╝
</pre>

**▌ CHOOSE YOUR CHARACTER · DEV · DESIGN · BA · PM · QA ▐**

<sub>The one OS the whole team actually shares.</sub>

[![Proprietary](https://img.shields.io/badge/LICENSE-PROPRIETARY-ff0040?style=for-the-badge&labelColor=000)](LICENSE)
[![Last Commit](https://img.shields.io/github/last-commit/kaushikdas0/spectrum-os?style=for-the-badge&color=ff6b1a&labelColor=000)](https://github.com/kaushikdas0/spectrum-os/commits/main)
[![Built for Claude Code](https://img.shields.io/badge/BUILT_FOR-CLAUDE_CODE-ff6b1a?style=for-the-badge&labelColor=000)](https://claude.com/claude-code)
[![Node 18+](https://img.shields.io/badge/NODE-%E2%89%A518-ff6b1a?style=for-the-badge&labelColor=000)](https://nodejs.org)

<sub>Built with love by <b>Kaushik</b>, inspired by <b>TÂCHES</b>, the original founder of GSD, whose foundational work this project gratefully extends.</sub>

</div>

---

<details open>
<summary><b>▼ WHY SPECTRUMOS</b></summary>
<br>

spectrumOS lifts a beloved planning framework into a **harness layer** for end-to-end SDLC across larger enterprises and digital factories. At its center is the **context layer** — an ever-evolving, spec-driven approach to building software with AI. Equally made for designers, developers, testers, QA, and product managers, each with their own way to control the harness.

<div align="center">

<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 420" width="100%" style="max-width:800px;">
  <rect x="0" y="0" width="800" height="420" fill="#0a0a0a"/>
  <rect x="20" y="20" width="760" height="100" rx="4" fill="#111" stroke="#ff6b1a" stroke-width="1.5"/>
  <text x="35" y="42" font-family="Courier New, monospace" font-weight="bold" font-size="11" fill="#ff6b1a" letter-spacing="1.5">▌ HARNESS LAYER ▐</text>
  <rect x="35" y="55" width="170" height="50" rx="3" fill="#1a1a1a" stroke="#555" stroke-width="1"/>
  <text x="120" y="86" font-family="Courier New, monospace" font-size="13" fill="#e8e8e8" text-anchor="middle">Claude Code</text>
  <rect x="220" y="55" width="170" height="50" rx="3" fill="#1a1a1a" stroke="#555" stroke-width="1"/>
  <text x="305" y="86" font-family="Courier New, monospace" font-size="13" fill="#e8e8e8" text-anchor="middle">Codex</text>
  <rect x="405" y="55" width="170" height="50" rx="3" fill="#1a1a1a" stroke="#555" stroke-width="1"/>
  <text x="490" y="86" font-family="Courier New, monospace" font-size="13" fill="#e8e8e8" text-anchor="middle">Gemini</text>
  <rect x="590" y="55" width="170" height="50" rx="3" fill="#1a1a1a" stroke="#555" stroke-width="1"/>
  <text x="675" y="86" font-family="Courier New, monospace" font-size="13" fill="#e8e8e8" text-anchor="middle">Copilot</text>
  <line x1="400" y1="125" x2="400" y2="160" stroke="#ff6b1a" stroke-width="2"/>
  <polygon points="395,155 400,168 405,155" fill="#ff6b1a"/>
  <rect x="20" y="170" width="760" height="100" rx="4" fill="#111" stroke="#ff6b1a" stroke-width="1.5"/>
  <text x="35" y="192" font-family="Courier New, monospace" font-weight="bold" font-size="11" fill="#ff6b1a" letter-spacing="1.5">▌ CONTEXT LAYER · .planning/ ▐</text>
  <rect x="35" y="205" width="170" height="50" rx="3" fill="#1a1a1a" stroke="#555" stroke-width="1"/>
  <text x="120" y="236" font-family="Courier New, monospace" font-size="13" fill="#e8e8e8" text-anchor="middle">PROJECT.md</text>
  <rect x="220" y="205" width="170" height="50" rx="3" fill="#1a1a1a" stroke="#555" stroke-width="1"/>
  <text x="305" y="236" font-family="Courier New, monospace" font-size="13" fill="#e8e8e8" text-anchor="middle">ROADMAP.md</text>
  <rect x="405" y="205" width="170" height="50" rx="3" fill="#1a1a1a" stroke="#555" stroke-width="1"/>
  <text x="490" y="236" font-family="Courier New, monospace" font-size="13" fill="#e8e8e8" text-anchor="middle">REQUIREMENTS.md</text>
  <rect x="590" y="205" width="170" height="50" rx="3" fill="#1a1a1a" stroke="#555" stroke-width="1"/>
  <text x="675" y="236" font-family="Courier New, monospace" font-size="13" fill="#e8e8e8" text-anchor="middle">STATE.md</text>
  <line x1="400" y1="275" x2="400" y2="310" stroke="#ff6b1a" stroke-width="2"/>
  <polygon points="395,305 400,318 405,305" fill="#ff6b1a"/>
  <rect x="20" y="320" width="760" height="80" rx="4" fill="#111" stroke="#ff0040" stroke-width="1.5"/>
  <text x="35" y="342" font-family="Courier New, monospace" font-weight="bold" font-size="11" fill="#ff0040" letter-spacing="1.5">▌ YOUR CODEBASE ▐</text>
  <text x="400" y="378" font-family="Courier New, monospace" font-size="14" fill="#888" text-anchor="middle">where your code actually lives · this is the prize</text>
</svg>

</div>

</details>

---

> [!TIP]
> **▌ INSERT COIN ▐** First time? Jump to **[Install](#-install)** → **[Starting a Project](#-starting-a-project)** → **[The Loop](#-the-loop)** → **[A Day in the Life](#-a-day-in-the-life)**. Full surface lives in [docs/COMMANDS.md](docs/COMMANDS.md).

## ▼ INSTALL

You'll be given a `spectrum-os-<version>.tgz` package. Install it, no repo clone needed:

```bash
npm install -g spectrum-os-<version>.tgz   # 1. install the global CLI
spectrum-os                                # 2. wire into ~/.claude/
```

Then start Claude Code (`claude`) and switch on **Auto mode** for a frictionless flow (press `Shift + Tab` to cycle the permission mode to auto-accept).

**Upgrading:** same two steps with a newer `.tgz`. The installer redeploys the framework and leaves your projects' `.planning/` data untouched, so no migration is needed.

<details>
<summary>Install flags &amp; runtimes</summary>
<br>

Pass flags to the installer, e.g. `spectrum-os --minimal --claude`:

| Flag | Effect |
|---|---|
| `--global` | Install to `~/.claude/` (default for personal use) |
| `--minimal` | Only core commands, no agents/hooks |
| `--claude` / `--codex` / `--gemini` / `--copilot` | Target a specific runtime |

Full options in **[docs/USER-GUIDE.md](docs/USER-GUIDE.md)**.

</details>

<details>
<summary>Build from source (maintainers)</summary>
<br>

```bash
npm install                           # install root deps
npm run build                         # build hooks/dist + sdk/dist
node bin/install.js --claude --global # wire into ~/.claude/
```

The build step is required: `bin/install.js` copies built artifacts from `hooks/dist/` and expects `sdk/dist/cli.js` for `/spec-*` commands to function.

</details>

---

## ▼ STARTING A PROJECT

Two ways into the loop, depending on whether you're starting from scratch or wading into something that already exists.

### 🌱 ・ GREEN FIELD · NEW PROJECT

Nothing exists yet. spectrumOS asks questions, researches the domain, generates requirements, and proposes a roadmap.

```
> /spec-new-project
```

That's it. The loop begins at step 1.

### 🏗️ ・ BROWN FIELD · EXISTING CODEBASE

There's already code, and probably already documentation, conventions, ADRs, coding-style guides. spectrumOS needs to see **both** the code and your team's accumulated wisdom about it.

> [!IMPORTANT]
> **▌ STAGE 0 · GSD LEGACY CHECK ▐**
>
> Was the project previously managed by **GSD** (the framework spectrumOS was inspired from)?
>
> **Step A — Migrate the project's `.planning/`:**
>
> ```
> > /spec-migrate-from-gsd              ▌ dry-run, see what would change
> > /spec-migrate-from-gsd --apply      ▌ rewrite + write migration-report.md
> ```
>
> Safe-rewrites the 56 commands with 1:1 spec equivalents. The 20 GSD commands with no direct equivalent get logged for human review (e.g. `/gsd:do` → consider `/spec-quick` or `/spec-fast`).
>
> **Note on the folder name:** `.planning/` is *preserved permanently* — spectrum-os reads from the same directory GSD wrote to (the convention was inherited unchanged from the fork). The folder stays `.planning/` forever; no future rename to `.spectrumos/` is planned.
>
> **Step B — Remove GSD globally from `~/.claude/`** (only needed once per machine). Two reasons to do this: **(1) namespace overlap** — both `/gsd:*` and `/spec-*` show up in your slash-command list; **(2) context cost** — every skill installed in `~/.claude/` ships its description into the available-skills system message on every conversation. Leaving 50+ unused GSD skills loaded burns tokens you're paying for in every session.
>
> One command does it all — cleans the deployed `~/.claude/` artifacts and scrubs `settings.json` registration in a single pass:
>
> ```bash
> npx get-shit-done-cc --uninstall
> ```
>
> User state at `~/.gsd/` and `~/.cache/gsd/` is intentionally left alone — it may contain API keys or learnings worth keeping.
>
> **Also scrub your user-global instructions if you have any.** Run `grep -nE '/gsd:|gsd-tools|get-shit-done' ~/.claude/CLAUDE.md` to find references in your personal global Claude instructions, and rewrite them by hand using the same map (e.g. `/gsd:plan-phase` → `/spec-plan-phase`). This file is shared across all your projects, so spectrum-os deliberately doesn't auto-edit it — you might still want some GSD refs there for other projects.
>
> Skip this entire stage if the project (and your machine) were never touched by GSD.

**Step 1 — Gather your existing docs and design assets.**

Drop your engineering docs and design assets into the conventional folders so the team — and the agents — always know where to look:

```
docs/
├── adr/         ▌ Architecture Decision Records
├── prd/         ▌ Product Requirements
├── specs/       ▌ Technical specifications
├── rfc/         ▌ Requests for Comment
└── design/      ▌ DLS, Figma exports, design tokens, image extracts — anything visual
```

Or pass an explicit `--manifest <file>` listing each doc and its type.

> [!NOTE]
> `/spec-ingest-docs` auto-ingests the four engineering folders (ADR / PRD / SPEC / RFC) into `.planning/`. The `design/` folder is a stable parking lot for visual context — Figma URLs, design tokens, exported components, screenshot references. Park assets here so designer commands (`/spec-sketch`, `/spec-ui-phase`, `/spec-ui-review`) and human teammates always find them in one place.

**Step 2 — Ingest the docs into spectrumOS.**

```
> /spec-ingest-docs docs/
```

Synthesises the discovered docs into `.planning/PROJECT.md` + `REQUIREMENTS.md` + `ROADMAP.md` + `STATE.md`, using the precedence `ADR > SPEC > PRD > DOC` to auto-resolve conflicts. Anything unresolved lands in `.planning/INGEST-CONFLICTS.md` for you to review.

**Step 3 — Map the code.**

```
> /spec-map-codebase
```

Four parallel agents read the code and write seven structured docs into `.planning/codebase/` covering tech stack, architecture, conventions, integrations, structure, concerns, and quality.

**Step 4 — Enter the loop.**

```
> /spec-discuss-phase 1
```

You now have both human-written context (`.planning/`) and code-derived context (`.planning/codebase/`). Discuss, plan, execute — same as Green Field from here on.

> [!TIP]
> No existing docs? Skip steps 1–2 and run `/spec-map-codebase` directly. Code-only context is a softer brown field but works.

---

## ▼ THE LOOP

Six commands. Each does one thing. Loop until milestone done.

```
   ╔════════╗    ╔══════════╗    ╔════════╗    ╔═════════╗    ╔════════╗    ╔════════╗
   ║   1    ║───>║    2     ║───>║   3    ║───>║    4    ║───>║   5    ║───>║   6    ║
   ║  INIT  ║    ║ DISCUSS  ║    ║  PLAN  ║    ║ EXECUTE ║    ║ VERIFY ║    ║  SHIP  ║
   ╚════════╝    ╚══════════╝    ╚════════╝    ╚═════════╝    ╚════════╝    ╚════╤═══╝
                                                                                  │
                          ┌───────────────────────────────────────────────────────┘
                          v
                   ╔════════════════╗
                   ║ NEW MILESTONE  ║───> 1UP · LOOP REPEATS
                   ╚════════════════╝
```

<details>
<summary><b>The 6 steps, in detail</b></summary>
<br>

| # | Command | What it does |
|---|---|---|
| 1 | `/spec-new-project` | Questions → research → requirements → roadmap. *Existing codebase? See [Brown Field](#-brown-field--existing-codebase) above.* |
| 2 | `/spec-discuss-phase <N>` | Capture implementation decisions for phase N before anything is planned. |
| 3 | `/spec-plan-phase <N>` | Research → plan → verify loop. Each plan small enough for a fresh context window. |
| 4 | `/spec-execute-phase <N>` | Plans run in parallel waves. Fresh 200k context per executor. Atomic commits. |
| 5 | `/spec-verify-work <N>` | Walk through what was built. Failures get diagnosed fix plans ready for re-execution. |
| 6 | `/spec-ship <N>` → `/spec-complete-milestone` → `/spec-new-milestone` | Loop until milestone done. Archive, tag, start fresh. |

</details>

---

## ▼ A DAY IN THE LIFE

Five characters. One harness. Pick the workflow that matches your weapon.

### 🎨 ・ DESIGNER

> You sketched the new dashboard last night. This morning you want a working prototype + a kitchen-sink page showing every component, before the design review at 3pm.

```
> /spec-sketch              ▌ wireframe in plain language
> /spec-ui-phase            ▌ generate UI-SPEC.md from your sketch
> /spec-mvp-phase           ▌ ship a working prototype, not production
> /spec-ui-review           ▌ audit against your design system
```

> [!TIP]
> **Kitchen sink:** during `/spec-mvp-phase`, ask the agent for a *kitchen-sink* page — a single route rendering every component, control state, and edge case. Hand that URL to QA and to the design review. One page, everything visible.

### 🏛️ ・ ARCHITECT

> A project just got handed to you. Whether the code's fresh or twenty years old, your job is to understand the domain, map any existing code, propose an architecture, and frame the discussion before a single line gets written.

```
> /spec-map-codebase        ▌ analyze existing code, build a mental model
> /spec-explore             ▌ research patterns and tech choices
> /spec-discuss-phase       ▌ capture architecture decisions
> /spec-spec-phase          ▌ write the formal spec before planning
```

### 🚀 ・ FORWARD DEPLOYED ENGINEER

> Three plans are queued. The customer is breathing down your neck. You need to execute fast, debug what breaks, and ship the result before standup.

```
> /spec-execute-phase       ▌ parallel waves, atomic commits
> /spec-quick               ▌ urgent one-off, smaller than a phase
> /spec-fast                ▌ trivial work inline, no agent overhead
> /spec-debug               ▌ systematic root-cause when something breaks
> /spec-ship                ▌ PR + review + ready to merge
```

### ✅ ・ UAT TESTER

> Engineering says it's done. You're not sure. You need to walk every requirement, generate tests for what's missing, and produce a yes-or-no audit trail.

```
> /spec-verify-work         ▌ interactive walk through what was built
> /spec-validate-phase      ▌ retroactive audit of validation coverage
> /spec-audit-uat           ▌ cross-phase audit of outstanding UAT items
> /spec-add-tests           ▌ generate tests for completed phases from UAT criteria
```

### 📋 ・ BA / PM

> The roadmap moved. You need to surface what's blocked, what shipped, what's next, and have a status update ready by EOD.

```
> /spec-progress            ▌ where are we, what's blocked, what's next
> /spec-stats               ▌ phases, plans, requirements, timeline metrics
> /spec-audit-milestone     ▌ does this milestone actually deliver what it promised
> /spec-milestone-summary   ▌ generate stakeholder-ready summary
```

---

## ▼ WORKING AS A TEAM

`.planning/` is committed to git, so your roadmap, decisions, and summaries travel with the repo: every teammate pulls the shared context. Two opt-in switches keep things tidy once more than one person works the same project. Both are **off by default**, so solo behaviour is unchanged.

### 👥 ・ NAMESPACED PHASES

Turn this on so each person's phases carry their handle (taken from `git config user.email`). Two people can then add phases at the same time without clashing.

```json
// .planning/config.json
{ "phase_namespacing": true }
```

```
phases/01-auth        ▌ off (default): plain numbers
phases/kd-01-auth     ▌ on: prefixed with your handle, so kd-01 and mira-01 never collide
```

> [!NOTE]
> Needs a git identity. If `user.email` / `user.name` are unset, the tool stops and asks you to set one rather than guess a name. See [docs/CONFIGURATION.md](docs/CONFIGURATION.md).

### 🔒 ・ ONE OWNER PER FEATURE

A small shared ledger so two people never build the same feature at once. Claim it, work it, publish it back.

```
> spec-sdk query ownership.claim auth     ▌ take it (rejects if someone else holds it)
> spec-sdk query ownership.status         ▌ who owns what right now
> spec-sdk query ownership.publish auth   ▌ hand it back to the team
```

The auto-generated indexes (the knowledge graph and other derived files) are kept out of git for you, so they never cause merge conflicts. Shared notes stay shared; regenerated files stay local.

---

## ▼ COMMANDS AT A GLANCE

| Command | What it does |
|---|---|
| `/spec-new-project` | Bootstrap a new project |
| `/spec-discuss-phase [N]` | Capture decisions |
| `/spec-plan-phase [N]` | Research + plan + verify |
| `/spec-execute-phase <N>` | Parallel execution |
| `/spec-verify-work [N]` | Manual acceptance testing |
| `/spec-ship [N]` | Create PR |
| `/spec-progress --next` | Auto-detect next step |

> [!NOTE]
> Full command surface lives in [docs/COMMANDS.md](docs/COMMANDS.md). Each command is one verb — no subcommands, no flags-soup.

---

## ▼ RUNTIMES

The AI runtimes spectrumOS speaks out of the box.

<p>
  <a href="https://claude.com/claude-code"><img alt="Claude Code" src="https://img.shields.io/badge/CLAUDE_CODE-READY-ff6b1a?style=for-the-badge&logo=anthropic&logoColor=ff6b1a&labelColor=000"></a>
  <a href="https://openai.com/codex"><img alt="Codex" src="https://img.shields.io/badge/CODEX-READY-ff6b1a?style=for-the-badge&logo=openai&logoColor=ff6b1a&labelColor=000"></a>
  <a href="https://gemini.google.com"><img alt="Gemini" src="https://img.shields.io/badge/GEMINI-READY-ff6b1a?style=for-the-badge&logo=googlegemini&logoColor=ff6b1a&labelColor=000"></a>
  <a href="https://github.com/features/copilot"><img alt="Copilot" src="https://img.shields.io/badge/COPILOT-READY-ff6b1a?style=for-the-badge&logo=githubcopilot&logoColor=ff6b1a&labelColor=000"></a>
</p>

---

## ▼ THE STATUSLINE

What spectrum looks like in your terminal while you work. The orange hex (`⬢`) is the brand anchor — always leftmost, always lit. Everything after it renders in dim grey.

```
⬢ spec │ Sonnet 4.6 │ Phase 5 · planning │ my-project │ 67k/200k (33%) │ last: /spec-discuss-phase
```

Each segment is conditional — only renders when its data source is present:

| # | Segment | Source | Hidden when |
|---|---|---|---|
| 1 | `⬢ spec` | brand anchor | always shown |
| 2 | `Sonnet 4.6` | Claude session | always shown |
| 3 | `Phase 5 · planning` | `.planning/STATE.md` | no spectrum project at cwd |
| 4 | `my-project` | working directory | always shown |
| 5 | `67k/200k (33%)` | session context | always shown |
| 6 | `last: /spec-discuss-phase` | session transcript | `statusline.show_last_command: false` |

The statusline ships at `hooks/spec-statusline.js`. The installer wires it as your `statusLine.command` on a fresh install. If you already have one configured, re-run with `--force-statusline` to override.

> [!NOTE]
> **▌ COMING SOON ▐** A `ctx-mode: $X saved · N% eff` segment is designed (see [SUPER POWERS](#-spectrum-super-powers) → Context efficiency). When context-mode is installed, the statusline will show real-time savings — pulling `context-mode stats --json` via a 60s cache so the render stays fast.

---

## ▼ SPECTRUM SUPER POWERS

Curated capabilities you can layer on top of the harness — pick what your role needs, skip what you don't. Named by **capability**, not by product, so the implementation can swap out without breaking the recipe.

> **One command installs them:** `/spec-setup-extras` shows the menu below, you pick a few or all, the agent walks the install.

```
 ╔══════════════════════════════════════════════════════════════════════╗
 ║              ▌ SPECTRUM SUPER POWERS · POWER-UP MENU ▐               ║
 ╚══════════════════════════════════════════════════════════════════════╝

   #  Tier     Capability                          Personas
   ──────────────────────────────────────────────────────────────────────
   1  CORE     Context efficiency                  All
   2  CORE     Version control & PR flow           All

   3  PERSONA  UI/UX design system generation      Designer · FDE
   4  PERSONA  Frontend design audit               Designer · FDE
   5  PERSONA  Collaborative diagramming           Designer · Architect · BA-PM
   6  PERSONA  Browser automation                  FDE · UAT
   7  PERSONA  HTML-to-video rendering             Designer · FDE
   ──────────────────────────────────────────────────────────────────────
   > /spec-setup-extras       ▌ install picker · cheap validation built in
   > /spec-validate-extras    ▌ re-verify the catalog (run quarterly)
```

### Multiple implementations per capability

Some capabilities have a built-in choice — the menu names the capability once, then asks which implementation fits your stack:

| Capability | Implementation choices |
|---|---|
| Version control & PR flow | GitHub CLI · Bitbucket CLI · GitLab CLI |
| Browser automation | agent-browser · Playwright |

New implementations slot into the catalog without restructuring the menu. **Capability names stay stable; products evolve.**

### Validation, baked in

Every entry in the catalog ships with **provenance** — source repo, npm package, license, last-verified date. Before installing, `/spec-setup-extras` runs cheap pre-flight checks:

- Source URL still resolves
- npm package still exists on the registry
- Required prereqs present (Node version, disk space, etc.)
- License matches what was promised

Stale or broken entries fail fast — before any change to your system. `/spec-validate-extras` re-runs those checks across the catalog on demand. Run it quarterly. Run it before a release.

The catalog lives at [`spectrum-os/references/extras-catalog.md`](spectrum-os/references/extras-catalog.md) (inside the framework data dir, so the installer ships it). Source URLs for v1 entries come from the [AI Life Skills catalog](https://github.com/kaushikdas0/ai-life-skills). The Bitbucket CLI slot is a known gap — Atlassian does not ship a first-party `gh`-equivalent — and `/spec-setup-extras` will prompt the user to pick a community option at install time.

---

## ▼ DOCUMENTATION

<details>
<summary>Where to read more</summary>
<br>

| Doc | What's in it |
|---|---|
| [User Guide](docs/USER-GUIDE.md) | End-to-end walkthrough, install options, configuration |
| [Commands](docs/COMMANDS.md) | Every command with flags and examples |
| [Configuration](docs/CONFIGURATION.md) | Config schema, model profiles, git branching |
| [Architecture](docs/ARCHITECTURE.md) | How the multi-agent orchestration works |
| [CLI Tools](docs/CLI-TOOLS.md) | `spec-sdk query` and programmatic SDK |

</details>

<details>
<summary>Troubleshooting</summary>
<br>

> [!IMPORTANT]
> Commands not showing up? **Restart Claude Code after install.** spectrumOS installs to `~/.claude/skills/spec-*/`.

Re-run the installer to fix install state — it's idempotent.

</details>

---

<div align="center">

<sub>▌ PROPRIETARY · DO NOT SHARE · GAME OVER ▐</sub>
<br>
<sub>© 2026 Kaushik Das · All rights reserved · See <a href="LICENSE">LICENSE</a></sub>

</div>
