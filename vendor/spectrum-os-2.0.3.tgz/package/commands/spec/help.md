---
name: spec:help
description: Show available spectrumOS commands and usage guide
allowed-tools:
  - Read
---
<objective>
Display the complete spectrumOS command reference.

Output ONLY the reference content below. The one permitted modification is the banner's version line: replace the literal token {{VERSION}} with the contents of ~/.claude/spectrum-os/VERSION (omit the version line if that file is missing or unreadable). Do NOT add:
- Project-specific analysis
- Git status or file context
- Next-step suggestions
- Any commentary beyond the reference
</objective>

<execution_context>
@~/.claude/spectrum-os/workflows/help.md
@~/.claude/spectrum-os/VERSION
</execution_context>

<process>
Execute end-to-end.
Display the reference content directly. The only change you make is substituting {{VERSION}} in the banner with the contents of ~/.claude/spectrum-os/VERSION; make no other additions or modifications.
</process>
