---
name: spec:import
description: Ingest external plans with conflict detection against project decisions before writing anything.
argument-hint: "--from <filepath>"
allowed-tools:
  - Read
  - Write
  - Edit
  - Bash
  - Glob
  - Grep
  - AskUserQuestion
  - Agent
---

<objective>
Import external plan files into the spectrumOS planning system with conflict detection against PROJECT.md decisions.

- **--from**: Import an external plan file, detect conflicts, write as spectrumOS PLAN.md, validate via spec-plan-checker.
</objective>

<execution_context>
@~/.claude/spectrum-os/workflows/import.md
@~/.claude/spectrum-os/references/ui-brand.md
@~/.claude/spectrum-os/references/gate-prompts.md
@~/.claude/spectrum-os/references/doc-conflict-engine.md
</execution_context>

<context>
$ARGUMENTS
</context>

<process>
Execute the import workflow end-to-end.
</process>
