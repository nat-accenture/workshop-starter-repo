---
name: spec:migrate-from-gsd
description: Scan a project's .planning/ + CLAUDE.md for GSD-flavored references and rewrite them to spec-* equivalents. Generates a report for unresolved commands.
argument-hint: "[path] [--apply|--report-only]"
allowed-tools:
  - Read
  - Write
  - Edit
  - Bash
  - Glob
  - Grep
---

<objective>
Migrate a project from GSD framework conventions to spectrum-os conventions.

Scans `.planning/**/*.md` and the root `CLAUDE.md` (if present) for GSD markers, performs safe 1:1 rewrites where a direct spec equivalent exists, and logs unresolved references to `migration-report.md` for human review. Default behaviour is **dry-run** — pass `--apply` to actually rewrite.

**Safe rewrites (always-on):**
- `/gsd:<slug>` → `/spec-<slug>` (only for slugs in the resolvable set — 56 commands)
- `gsd-tools` → `spec-tools`
- `~/.claude/get-shit-done/` → `~/.claude/spectrum-os/`
- `gsd-file-manifest` → `spec-file-manifest`

**Unresolved commands (20 — no 1:1 spec equivalent, never silently rewritten):**
`do`, `plant-seed`, `note`, `add-todo`, `add-backlog`, `next`, `session-report`, `set-profile`, `list-phase-assumptions`, `reapply-patches`, `join-discord`, `research-phase`, `plan-milestone-gaps`, `check-todos`, `add-phase`, `insert-phase`, `remove-phase`, `new-workspace`, `remove-workspace`, `list-workspaces`

Each unresolved match is logged with a suggested human action (e.g. `gsd:do` → consider `/spec-quick` or `/spec-fast`).

**Out-of-zone refs:** after the safe-rewrite zone is handled, the command also scans the rest of the repo with smart ignores (`.git`, `node_modules`, `dist`, `build`, `.next`, `coverage`) and lists any additional GSD references found in `docs/`, `README.md`, source code, tests, CI configs, etc. These are **never** auto-rewritten — they're surfaced in `migration-report.md` under "References outside the safe-rewrite zone" with file:line + suggested action so the user can review and edit by hand.
</objective>

<execution_context>
@~/.claude/spectrum-os/workflows/migrate-from-gsd.md
</execution_context>

<flags>
- **(no flag)**: dry-run — report what would change, write nothing.
- **--apply**: perform the safe rewrites in place and write `migration-report.md`.
- **--report-only**: scan + write `migration-report.md` without performing any rewrites.
</flags>

<context>
Arguments: $ARGUMENTS

Parse:
- First non-flag token = project path (default: current working directory).
- `--apply` enables in-place rewrites.
- `--report-only` writes the report only, no rewrites (mutually exclusive with `--apply`; if both given, `--report-only` wins).
</context>

<process>
Execute the migration workflow end-to-end.
</process>
