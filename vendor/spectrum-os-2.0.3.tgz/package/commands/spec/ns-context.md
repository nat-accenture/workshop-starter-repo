---
name: spec-context
description: "codebase intelligence | map graphify docs learnings"
argument-hint: ""
allowed-tools:
  - Read
  - Skill
---

Route to the appropriate codebase-intelligence skill based on the user's intent.
`spec-scan` and `spec-intel` were folded into `spec-map-codebase` flags by #2790.

| User wants | Invoke |
|---|---|
| Map the full codebase structure | spec-map-codebase |
| Quick lightweight codebase scan | spec-map-codebase --fast |
| Query mapped intelligence files | spec-map-codebase --query |
| Generate a knowledge graph | spec-graphify |
| Update project documentation | spec-docs-update |
| Extract learnings from a completed phase | spec-extract-learnings |

Invoke the matched skill directly using the Skill tool.
