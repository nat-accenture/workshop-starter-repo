---
name: spec-ideate
description: "exploration capture | explore sketch spike spec capture"
argument-hint: ""
allowed-tools:
  - Read
  - Skill
---

Route to the appropriate exploration / capture skill based on the user's intent.
`spec-note`, `spec-add-todo`, `spec-add-backlog`, and `spec-plant-seed` were folded
into `spec-capture` (with `--note`, default, `--backlog`, `--seed` modes) by
#2790. The capture target lists pending todos via `--list`.

| User wants | Invoke |
|---|---|
| Explore an idea or opportunity | spec-explore |
| Sketch out a rough design or plan | spec-sketch |
| Time-boxed technical spike | spec-spike |
| Write a spec for a phase | spec-spec-phase |
| Capture a thought (todo / note / backlog / seed) | spec-capture |

Invoke the matched skill directly using the Skill tool.
