---
name: spec-manage
description: "config workspace | workstreams thread update ship inbox"
argument-hint: ""
allowed-tools:
  - Read
  - Skill
---

Route to the appropriate management skill based on the user's intent.
`spec-config` (settings + advanced + integrations + profile) and `spec-workspace`
(new + list + remove) are post-#2790 consolidated entries.

| User wants | Invoke |
|---|---|
| Configure spectrumOS settings (basic / advanced / integrations / profile) | spec-config |
| Manage workspaces (create / list / remove) | spec-workspace |
| Manage parallel workstreams | spec-workstreams |
| Continue work in a fresh context thread | spec-thread |
| Pause current work | spec-pause-work |
| Resume paused work | spec-resume-work |
| Update the spectrumOS installation | spec-update |
| Ship completed work | spec-ship |
| Process inbox items | spec-inbox |
| Create a clean PR branch | spec-pr-branch |
| Undo the last spectrumOS action | spec-undo |

Invoke the matched skill directly using the Skill tool.
