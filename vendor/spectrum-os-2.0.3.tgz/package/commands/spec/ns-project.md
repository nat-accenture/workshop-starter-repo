---
name: spec-project
description: "project lifecycle | milestones audits summary"
argument-hint: ""
allowed-tools:
  - Read
  - Skill
---

Route to the appropriate project / milestone skill based on the user's intent.
`spec-plan-milestone-gaps` was deleted by #2790 — gap planning now happens
inline as part of `spec-audit-milestone`'s output.

| User wants | Invoke |
|---|---|
| Start a new project | spec-new-project |
| Create a new milestone | spec-new-milestone |
| Complete the current milestone | spec-complete-milestone |
| Audit a milestone for issues | spec-audit-milestone |
| Summarize milestone status | spec-milestone-summary |

Invoke the matched skill directly using the Skill tool.
