---
name: spec-review
description: "quality gates | code review debug audit security eval ui"
argument-hint: ""
allowed-tools:
  - Read
  - Skill
---

Route to the appropriate quality / review skill based on the user's intent.
`spec-code-review-fix` was absorbed by `spec-code-review --fix` in #2790.

| User wants | Invoke |
|---|---|
| Review code for quality and correctness | spec-code-review |
| Auto-fix code review findings | spec-code-review --fix |
| Audit UAT / acceptance testing | spec-audit-uat |
| Security review of a phase | spec-secure-phase |
| Evaluate AI response quality | spec-eval-review |
| Review UI for design and accessibility | spec-ui-review |
| Validate phase outputs | spec-validate-phase |
| Debug a failing feature or error | spec-debug |
| Forensic investigation of a broken system | spec-forensics |

Invoke the matched skill directly using the Skill tool.
