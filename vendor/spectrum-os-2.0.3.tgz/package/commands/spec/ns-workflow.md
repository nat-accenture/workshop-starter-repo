---
name: spec-workflow
description: "workflow | discuss plan execute verify phase progress"
argument-hint: ""
allowed-tools:
  - Read
  - Skill
---

Route to the appropriate phase-pipeline skill based on the user's intent.
Sub-skill names below are post-#2790 consolidated targets — `spec-phase`
absorbs the former add/insert/remove/edit-phase commands and `spec-progress`
absorbs the former next/do commands.

| User wants | Invoke |
|---|---|
| Gather context before planning | spec-discuss-phase |
| Clarify what a phase delivers | spec-spec-phase |
| Create a PLAN.md | spec-plan-phase |
| Execute plans in a phase | spec-execute-phase |
| Verify built features through UAT | spec-verify-work |
| Add / insert / remove / edit a phase | spec-phase |
| Advance to the next logical step | spec-progress |
| Offload planning to the ultraplan cloud | spec-ultraplan-phase |
| Cross-AI plan review convergence loop | spec-plan-review-convergence |

Invoke the matched skill directly using the Skill tool.
