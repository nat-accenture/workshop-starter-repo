---
name: spec:setup-extras
description: Interactive picker for the SPECTRUM SUPER POWERS catalog. Shows the menu, runs cheap pre-flight checks on selected entries, then follows each entry's official install steps from spectrum-os/references/extras-catalog.md.
argument-hint: "[--all | <capability-number>...]"
allowed-tools:
  - Read
  - Bash
  - AskUserQuestion
  - WebFetch
---

<objective>
Install one or more capabilities from the spectrumOS extras catalog.

Reads `spectrum-os/references/extras-catalog.md` as the source of truth — capability names, implementation choices, provenance, and prose install steps. Renders the picker, asks the user which capabilities (and, for entries with multiple implementations like #2 version control and #6 browser automation, which variant). For each selection, runs the four pre-flight checks from the catalog's validation contract, surfaces any failures, and on confirmation follows the *Install (from upstream)* prose for that entry.

The catalog stores install steps as prose lifted from each upstream project's official docs. The workflow reads the prose and executes it — it does not hardcode install commands.
</objective>

<execution_context>
@~/.claude/spectrum-os/workflows/setup-extras.md
</execution_context>

<flags>
- **(no flag)**: interactive — render the full picker, user selects from a multi-select list.
- **--all**: skip the picker, attempt every catalog entry. Useful for fresh-machine setup.
- **<capability-number>...**: skip the picker for the listed entries (e.g. `2 6` installs Version control + Browser automation). For entries with implementation choices, the implementation prompt still appears.
</flags>

<context>
Arguments: $ARGUMENTS

Parse:
- `--all` → SELECT-ALL mode
- Bare digits (`1`–`7`) → SELECT-LISTED mode; treat each digit as a capability number from the catalog
- Anything else (including empty) → INTERACTIVE mode (default)
</context>

<process>
Execute the setup-extras workflow end-to-end.
</process>
