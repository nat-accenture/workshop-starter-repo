---
name: spec:validate-extras
description: Non-interactive sweep of spectrum-os/references/extras-catalog.md — runs the four cheap pre-flight checks on every catalog entry and emits a ✓/⚠/✗ table. No install action; safe to run quarterly or before releases.
argument-hint: "[--json | <capability-number>...]"
allowed-tools:
  - Read
  - Bash
  - WebFetch
---

<objective>
Verify every entry in `spectrum-os/references/extras-catalog.md` is still installable without changing anything on the user's system.

For each entry, runs the catalog's four pre-flight checks:
1. Source URL resolves (HTTP 200 or 30x→200)
2. npm package exists on the registry (if any install step references one)
3. License matches what's advertised at the source (if discoverable)
4. `last-verified` date is within 180 days

Emits a status table per implementation: ✓ (all four pass), ⚠ (warnings — stale date, missing license, but installable), ✗ (one or more hard checks fail — entry is broken). No prompts. No installs. No filesystem writes outside an optional report file.
</objective>

<execution_context>
@~/.claude/spectrum-os/workflows/validate-extras.md
</execution_context>

<flags>
- **(no flag)**: human-readable table on stdout.
- **--json**: machine-readable JSON output (for CI integration).
- **<capability-number>...**: restrict the sweep to listed entries (e.g. `2 6` validates Version control + Browser automation).
</flags>

<context>
Arguments: $ARGUMENTS

Parse:
- `--json` → JSON-OUT mode (otherwise TABLE-OUT)
- Bare digits (`1`–`7`) → restrict to those capability numbers
- Default → sweep every entry in `spectrum-os/references/extras-catalog.md`, emit table
</context>

<process>
Execute the validate-extras workflow end-to-end.
</process>
