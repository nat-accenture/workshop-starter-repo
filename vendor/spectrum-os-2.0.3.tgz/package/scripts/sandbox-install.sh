#!/usr/bin/env bash
# scripts/sandbox-install.sh — sandboxed spectrumOS install for testing.
# Wipes a temp CLAUDE_CONFIG_DIR, installs spectrumOS into it, verifies.
# Real ~/.claude/ is never touched.
set -euo pipefail

SANDBOX="${SPECTRUM_TEST_SANDBOX:-/tmp/spectrum-cc-test}"
REPO="$(cd "$(dirname "$0")/.." && pwd)"

# Safety: refuse anything that looks like real Claude config
case "$SANDBOX" in
  "$HOME"|"$HOME/"|"$HOME/.claude"|"$HOME/.claude/"|/|"")
    echo "refusing to use '$SANDBOX' as sandbox" >&2
    exit 1
    ;;
esac

echo "→ wiping $SANDBOX"
rm -rf "$SANDBOX"
mkdir -p "$SANDBOX"

echo "→ installing into $SANDBOX"
CLAUDE_CONFIG_DIR="$SANDBOX" node "$REPO/bin/install.js" --claude --global

echo
echo "→ verifying"
echo "  spectrum-os files:  $(find "$SANDBOX/spectrum-os" -type f 2>/dev/null | wc -l | tr -d ' ')"
echo "  spec-* hooks:       $(ls "$SANDBOX/hooks/"spec-* 2>/dev/null | wc -l | tr -d ' ')"
echo "  spec-* agents:      $(ls "$SANDBOX/agents/"spec-*.md 2>/dev/null | wc -l | tr -d ' ')"
echo "  spec-* skills:      $(ls "$SANDBOX/skills/" 2>/dev/null | wc -l | tr -d ' ')"
echo "  spec-* in settings: $(grep -c 'spec-' "$SANDBOX/settings.json" 2>/dev/null || echo 0)"

residue=$( { grep -rEhno "\b(GSD|gsd|[Gg]et[ -]?[Ss]hit[ -]?[Dd]one)\b" "$SANDBOX" 2>/dev/null || true; } \
  | { grep -vE "learningsDelete|cmdLearningsDelete" || true; } | wc -l | tr -d ' ')
if [ "$residue" = "0" ]; then
  echo "  GSD residue check:  ✓ clean"
else
  echo "  GSD residue check:  ✗ $residue matches (showing first 20):"
  grep -rEn "\b(GSD|gsd|[Gg]et[ -]?[Ss]hit[ -]?[Dd]one)\b" "$SANDBOX" 2>/dev/null \
    | grep -vE "learningsDelete|cmdLearningsDelete" | head -20
fi

echo
echo "Ready. To test in Claude Code:"
echo "  export CLAUDE_CONFIG_DIR=$SANDBOX"
echo "  cd /path/to/your/test-project"
echo "  claude"
