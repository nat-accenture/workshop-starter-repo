import { describe, it, expect, afterEach } from 'vitest';
import { mkdtempSync, rmSync, writeFileSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import {
  slugifyHandle,
  deriveHandle,
  readStoredHandle,
  writeStoredHandle,
  resolveHandle,
  requireHandle,
  IDENTITY_FILE,
  MISSING_IDENTITY_MESSAGE,
} from './identity.js';
import { SpectrumOsError, ErrorClassification } from '../errors.js';

const tmpDirs: string[] = [];
function makeTmp(): string {
  const d = mkdtempSync(join(tmpdir(), 'spec-identity-'));
  tmpDirs.push(d);
  return d;
}
afterEach(() => {
  while (tmpDirs.length) {
    const d = tmpDirs.pop();
    if (d) {
      try {
        rmSync(d, { recursive: true, force: true });
      } catch {
        /* ignore cleanup errors */
      }
    }
  }
});

/** Run `fn` with git config sources neutralized so no identity resolves. */
function withNoGitIdentity(fn: () => void): void {
  const prevGlobal = process.env.GIT_CONFIG_GLOBAL;
  const prevSystem = process.env.GIT_CONFIG_SYSTEM;
  process.env.GIT_CONFIG_GLOBAL = '/dev/null';
  process.env.GIT_CONFIG_SYSTEM = '/dev/null';
  try {
    fn();
  } finally {
    if (prevGlobal === undefined) delete process.env.GIT_CONFIG_GLOBAL;
    else process.env.GIT_CONFIG_GLOBAL = prevGlobal;
    if (prevSystem === undefined) delete process.env.GIT_CONFIG_SYSTEM;
    else process.env.GIT_CONFIG_SYSTEM = prevSystem;
  }
}

describe('slugifyHandle', () => {
  it('lowercases and hyphenates', () => {
    expect(slugifyHandle('Kaushik Das')).toBe('kaushik-das');
  });
  it('collapses non-alphanumeric runs and trims hyphens', () => {
    expect(slugifyHandle('  K.D.  Das ')).toBe('k-d-das');
    expect(slugifyHandle('__kd__')).toBe('kd');
  });
  it('returns empty for null/garbage', () => {
    expect(slugifyHandle(null)).toBe('');
    expect(slugifyHandle('@#$%')).toBe('');
  });
});

describe('deriveHandle', () => {
  it('prefers the email local-part', () => {
    expect(deriveHandle('kd@example.com', 'Kaushik Das')).toEqual({ handle: 'kd', source: 'git-email' });
  });
  it('slugifies a dotted email local-part', () => {
    expect(deriveHandle('k.d.das@example.com', null)).toEqual({ handle: 'k-d-das', source: 'git-email' });
  });
  it('falls back to the name when email is empty or unusable', () => {
    expect(deriveHandle('', 'Mira Lin')).toEqual({ handle: 'mira-lin', source: 'git-name' });
    expect(deriveHandle('@@@', 'Mira')).toEqual({ handle: 'mira', source: 'git-name' });
  });
  it('returns null when neither yields a handle', () => {
    expect(deriveHandle('', '')).toBeNull();
    expect(deriveHandle(null, null)).toBeNull();
  });
});

describe('stored handle round-trip', () => {
  it('writes and reads back', () => {
    const d = makeTmp();
    writeStoredHandle(d, 'kd', 'git-email');
    expect(existsSync(join(d, IDENTITY_FILE))).toBe(true);
    expect(readStoredHandle(d)).toBe('kd');
  });
  it('returns null when absent or malformed', () => {
    const d = makeTmp();
    expect(readStoredHandle(d)).toBeNull();
    writeFileSync(join(d, IDENTITY_FILE), '{ not json');
    expect(readStoredHandle(d)).toBeNull();
  });
});

describe('resolveHandle / requireHandle', () => {
  it('a pinned override wins with source "override"', () => {
    const d = makeTmp();
    writeStoredHandle(d, 'pinned', 'override');
    expect(resolveHandle(d, d)).toEqual({ handle: 'pinned', source: 'override' });
    expect(requireHandle(d, d)).toEqual({ handle: 'pinned', source: 'override' });
  });

  it('hard-stops with a Blocked SpectrumOsError when no identity resolves', () => {
    const d = makeTmp(); // not a git repo, no pinned handle
    withNoGitIdentity(() => {
      expect(resolveHandle(d, d)).toBeNull();
      let thrown: unknown;
      try {
        requireHandle(d, d);
      } catch (e) {
        thrown = e;
      }
      expect(thrown).toBeInstanceOf(SpectrumOsError);
      expect((thrown as SpectrumOsError).classification).toBe(ErrorClassification.Blocked);
      expect((thrown as Error).message).toBe(MISSING_IDENTITY_MESSAGE);
    });
  });
});
