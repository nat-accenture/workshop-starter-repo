/**
 * Developer identity resolution for the multi-dev context layer (M5.1).
 *
 * Derives a stable developer handle from git identity, with a locally-pinned
 * override stored per clone. The handle is the namespace prefix used by
 * namespaced phase numbering (M5.2) and the ownership ledger (M5.3).
 *
 * Two resolution surfaces:
 * - `resolveHandle` — non-throwing; returns null when no identity is found.
 *   Use on read/display paths (e.g. solo display-collapse) that must not fail.
 * - `requireHandle` — throws the A1-guard hard stop when no identity is found.
 *   Use before any state-mutating operation. Decision 2026-06-18: no silent
 *   OS-username fallback (it collides across machines, e.g. two `ubuntu` boxes).
 *
 * MUST stay behaviourally in sync with spectrum-os/bin/lib/identity.cjs —
 * enforced by tests/identity-parity.test.cjs.
 *
 * @example
 * ```typescript
 * const { handle } = requireHandle('/project', '/project/.planning');
 * // → { handle: 'kd', source: 'git-email' }  (from kd@example.com)
 * ```
 */

import { spawnSync } from 'node:child_process';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { SpectrumOsError, ErrorClassification } from '../errors.js';

/** Filename for the locally-pinned handle, stored under `.planning/` (gitignored). */
export const IDENTITY_FILE = 'identity.local.json';

/** Where a resolved handle came from. */
export type IdentitySource = 'override' | 'git-email' | 'git-name';

export interface ResolvedIdentity {
  readonly handle: string;
  readonly source: IdentitySource;
}

/**
 * Actionable message shown when no developer identity can be resolved.
 * Mirrors the CJS copy in identity.cjs (parity test asserts the shape).
 */
export const MISSING_IDENTITY_MESSAGE = [
  'spectrumOS needs a developer identity but none was found.',
  'Set your git identity (used to namespace your work):',
  '  git config user.email "you@example.com"',
  '  git config user.name "Your Name"',
  'or pin an explicit handle in .planning/identity.local.json:',
  '  {"handle": "your-handle"}',
  'Then re-run. Halting before any change.',
].join('\n');

/**
 * Slugify a raw identity string into a safe handle: lowercase, alphanumeric
 * runs joined by single hyphens, no leading/trailing hyphens.
 */
export function slugifyHandle(raw: string | null | undefined): string {
  return (raw ?? '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

/**
 * Derive a handle from raw git email/name. The email local-part wins; the
 * name is the fallback. Returns null when neither yields a usable handle.
 */
export function deriveHandle(
  rawEmail: string | null | undefined,
  rawName: string | null | undefined,
): ResolvedIdentity | null {
  const email = (rawEmail ?? '').trim();
  if (email) {
    const local = email.split('@')[0];
    const handle = slugifyHandle(local);
    if (handle) return { handle, source: 'git-email' };
  }
  const handleFromName = slugifyHandle(rawName);
  if (handleFromName) return { handle: handleFromName, source: 'git-name' };
  return null;
}

/** Read a single git config value, or '' if unset/unavailable. */
function readGitConfig(cwd: string, key: string): string {
  const result = spawnSync('git', ['config', '--get', key], {
    cwd,
    stdio: 'pipe',
    encoding: 'utf-8',
  });
  return (result.stdout ?? '').toString().trim();
}

function identityFilePath(planningDir: string): string {
  return join(planningDir, IDENTITY_FILE);
}

/** Read the locally-pinned handle, or null when absent/malformed. */
export function readStoredHandle(planningDir: string): string | null {
  const file = identityFilePath(planningDir);
  if (!existsSync(file)) return null;
  try {
    const parsed = JSON.parse(readFileSync(file, 'utf-8')) as { handle?: unknown };
    const handle = typeof parsed.handle === 'string' ? slugifyHandle(parsed.handle) : '';
    return handle || null;
  } catch {
    return null;
  }
}

/** Pin a handle locally so git-config drift between machines can't fork the namespace. */
export function writeStoredHandle(planningDir: string, handle: string, source: IdentitySource): void {
  const payload = { handle, source, pinned_at: new Date().toISOString() };
  writeFileSync(identityFilePath(planningDir), `${JSON.stringify(payload, null, 2)}\n`);
}

export interface ResolveOptions {
  /** Persist a freshly-derived handle to `.planning/identity.local.json`. Default false. */
  readonly persist?: boolean;
}

/**
 * Resolve the developer handle without throwing.
 *
 * Order: locally-pinned override → derive from git email → derive from git name.
 * Returns null when none resolve (the caller decides whether that is fatal —
 * see `requireHandle`).
 */
export function resolveHandle(
  projectDir: string,
  planningDir: string,
  opts: ResolveOptions = {},
): ResolvedIdentity | null {
  const stored = readStoredHandle(planningDir);
  if (stored) return { handle: stored, source: 'override' };

  const derived = deriveHandle(
    readGitConfig(projectDir, 'user.email'),
    readGitConfig(projectDir, 'user.name'),
  );
  if (derived) {
    if (opts.persist && existsSync(planningDir)) {
      try {
        writeStoredHandle(planningDir, derived.handle, derived.source);
      } catch {
        // best-effort pin; resolution still succeeds in-memory
      }
    }
    return derived;
  }
  return null;
}

/**
 * Resolve the developer handle or hard-stop (A1-guard, decision 2026-06-18).
 *
 * Throws a Blocked SpectrumOsError with an actionable message when no identity
 * is found. Call this before any state-mutating operation; never on a pure read
 * path (use `resolveHandle` there).
 */
export function requireHandle(
  projectDir: string,
  planningDir: string,
  opts: ResolveOptions = {},
): ResolvedIdentity {
  const resolved = resolveHandle(projectDir, planningDir, opts);
  if (!resolved) {
    throw new SpectrumOsError(MISSING_IDENTITY_MESSAGE, ErrorClassification.Blocked);
  }
  return resolved;
}
