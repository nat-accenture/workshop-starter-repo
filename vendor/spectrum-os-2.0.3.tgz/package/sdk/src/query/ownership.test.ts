import { describe, it, expect, afterEach } from 'vitest';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { claim, publish, release, status, normalizeFeature } from './ownership.js';

const tmpDirs: string[] = [];
function makeTmp(): string {
  const d = mkdtempSync(join(tmpdir(), 'spec-own-ts-'));
  tmpDirs.push(d);
  return d;
}
function pin(dir: string, handle: string): void {
  writeFileSync(join(dir, 'identity.local.json'), JSON.stringify({ handle, source: 'override' }));
}
afterEach(() => {
  while (tmpDirs.length) {
    const d = tmpDirs.pop();
    if (d) {
      try {
        rmSync(d, { recursive: true, force: true });
      } catch {
        /* ignore */
      }
    }
  }
});

describe('ownership ledger', () => {
  it('normalizeFeature lowercases and slugifies', () => {
    expect(normalizeFeature('  Auth Flow! ')).toBe('auth-flow');
    expect(normalizeFeature(null)).toBe('');
  });

  it('claim takes ownership; status reflects it', () => {
    const d = makeTmp();
    pin(d, 'kd');
    const r = claim(d, d, 'auth');
    expect(r).toMatchObject({ ok: true, owner: 'kd', status: 'claimed' });
    expect((status(d, 'auth') as { entry: { owner: string } }).entry.owner).toBe('kd');
  });

  it('enforces single owner, allows redo after publish', () => {
    const d = makeTmp();
    pin(d, 'kd');
    claim(d, d, 'auth');
    pin(d, 'mira');
    expect(claim(d, d, 'auth')).toMatchObject({ ok: false });
    pin(d, 'kd');
    expect(publish(d, d, 'auth')).toMatchObject({ ok: true, status: 'published' });
    pin(d, 'mira');
    expect(claim(d, d, 'auth')).toMatchObject({ ok: true, redo: true, owner: 'mira' });
  });

  it('release frees the claim', () => {
    const d = makeTmp();
    pin(d, 'kd');
    claim(d, d, 'auth');
    expect(release(d, d, 'auth')).toMatchObject({ ok: true });
    expect((status(d, 'auth') as { entry: unknown }).entry).toBeNull();
  });
});
