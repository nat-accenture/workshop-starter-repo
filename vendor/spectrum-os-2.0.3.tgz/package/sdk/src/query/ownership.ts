/**
 * Ownership ledger for single-owner-per-feature check-in (M5.3 / workstream C).
 *
 * One owner holds a feature at a time; on publish the feature is marked
 * published (source-context propagation is workstream D); a published feature
 * can be re-claimed (redo). The ledger enforces one-at-a-time and prevents
 * double-claims.
 *
 * Stored at `.planning/ownership.json` (local for now). CJS mirror:
 * spectrum-os/bin/lib/ownership.cjs — parity asserted by tests/ownership-parity.test.cjs.
 */

import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { planningPaths } from './helpers.js';
import { requireHandle } from './identity.js';
import type { QueryHandler } from './utils.js';

export const LEDGER_FILE = 'ownership.json';
export const STATUS_CLAIMED = 'claimed';
export const STATUS_PUBLISHED = 'published';

export interface LedgerEntry {
  owner: string;
  status: string;
  updated_at: string;
}
export interface Ledger {
  version: number;
  features: Record<string, LedgerEntry>;
}

function ledgerPath(planningDir: string): string {
  return join(planningDir, LEDGER_FILE);
}

/** Normalize a feature key: lowercase, alphanumerics + . _ - , trimmed. */
export function normalizeFeature(feature: string | null | undefined): string {
  return String(feature ?? '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9._-]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

/** Read the ledger, returning a normalized shape even when absent/malformed. */
export function readLedger(planningDir: string): Ledger {
  const p = ledgerPath(planningDir);
  if (!existsSync(p)) return { version: 1, features: {} };
  try {
    const parsed = JSON.parse(readFileSync(p, 'utf-8')) as Partial<Ledger> | null;
    if (!parsed || typeof parsed !== 'object' || typeof parsed.features !== 'object' || parsed.features === null) {
      return { version: 1, features: {} };
    }
    return { version: parsed.version || 1, features: parsed.features as Record<string, LedgerEntry> };
  } catch {
    return { version: 1, features: {} };
  }
}

export function writeLedger(planningDir: string, ledger: Ledger): void {
  writeFileSync(ledgerPath(planningDir), `${JSON.stringify(ledger, null, 2)}\n`);
}

export interface OpResult {
  ok: boolean;
  feature?: string;
  owner?: string;
  status?: string;
  reason?: string;
  redo?: boolean;
}

/** Claim exclusive ownership. Allowed when unowned, mine, or published (redo). */
export function claim(planningDir: string, projectDir: string, feature: string): OpResult {
  const f = normalizeFeature(feature);
  if (!f) return { ok: false, reason: 'feature name required' };
  const { handle } = requireHandle(projectDir, planningDir, { persist: true });
  const ledger = readLedger(planningDir);
  const existing = ledger.features[f];
  if (existing && existing.owner !== handle && existing.status === STATUS_CLAIMED) {
    return { ok: false, feature: f, owner: existing.owner, status: existing.status, reason: `already claimed by ${existing.owner}` };
  }
  const redo = !!(existing && existing.status === STATUS_PUBLISHED);
  ledger.features[f] = { owner: handle, status: STATUS_CLAIMED, updated_at: new Date().toISOString() };
  writeLedger(planningDir, ledger);
  return { ok: true, feature: f, owner: handle, status: STATUS_CLAIMED, redo };
}

/** Mark my claimed feature as published. Only the current owner may publish. */
export function publish(planningDir: string, projectDir: string, feature: string): OpResult {
  const f = normalizeFeature(feature);
  if (!f) return { ok: false, reason: 'feature name required' };
  const { handle } = requireHandle(projectDir, planningDir, { persist: true });
  const ledger = readLedger(planningDir);
  const existing = ledger.features[f];
  if (!existing) return { ok: false, feature: f, reason: 'not claimed' };
  if (existing.owner !== handle) return { ok: false, feature: f, owner: existing.owner, reason: `owned by ${existing.owner}, not you` };
  ledger.features[f] = { owner: handle, status: STATUS_PUBLISHED, updated_at: new Date().toISOString() };
  writeLedger(planningDir, ledger);
  return { ok: true, feature: f, owner: handle, status: STATUS_PUBLISHED };
}

/** Release my claim. Only the current owner may release. */
export function release(planningDir: string, projectDir: string, feature: string): OpResult {
  const f = normalizeFeature(feature);
  if (!f) return { ok: false, reason: 'feature name required' };
  const { handle } = requireHandle(projectDir, planningDir, { persist: true });
  const ledger = readLedger(planningDir);
  const existing = ledger.features[f];
  if (!existing) return { ok: false, feature: f, reason: 'not claimed' };
  if (existing.owner !== handle) return { ok: false, feature: f, owner: existing.owner, reason: `owned by ${existing.owner}, not you` };
  delete ledger.features[f];
  writeLedger(planningDir, ledger);
  return { ok: true, feature: f, status: 'released' };
}

/** Report the whole ledger, or a single feature's entry. Read-only (no identity). */
export function status(planningDir: string, feature?: string): { features: Record<string, LedgerEntry> } | { feature: string; entry: LedgerEntry | null } {
  const ledger = readLedger(planningDir);
  if (feature) {
    const f = normalizeFeature(feature);
    return { feature: f, entry: ledger.features[f] || null };
  }
  return { features: ledger.features };
}

// ─── Query handlers (registered in the static catalog) ──────────────────────

export const ownershipClaim: QueryHandler = async (args, projectDir, workstream) => {
  const planningDir = planningPaths(projectDir, workstream).planning;
  return { data: claim(planningDir, projectDir, args[0]) };
};

export const ownershipPublish: QueryHandler = async (args, projectDir, workstream) => {
  const planningDir = planningPaths(projectDir, workstream).planning;
  return { data: publish(planningDir, projectDir, args[0]) };
};

export const ownershipRelease: QueryHandler = async (args, projectDir, workstream) => {
  const planningDir = planningPaths(projectDir, workstream).planning;
  return { data: release(planningDir, projectDir, args[0]) };
};

export const ownershipStatus: QueryHandler = async (args, projectDir, workstream) => {
  const planningDir = planningPaths(projectDir, workstream).planning;
  return { data: status(planningDir, args[0]) };
};
