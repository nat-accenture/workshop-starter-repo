# Spectrum Super Powers — extras catalog

Curated capabilities you can layer on top of the spectrumOS harness. Names describe **capability**, not product, so implementations can swap without breaking the menu.

**How this file is used.** `/spec-setup-extras` reads the catalog, renders a picker, runs the four pre-flight checks against the structured fields below, then executes each selected entry's *Install* command block verbatim. `/spec-validate-extras` runs the same checks without installing.

**Schema (per implementation):**

| Field | Meaning | Used by validator |
|---|---|---|
| `Source:` | Canonical upstream URL (GitHub repo or homepage) | Check 1: URL resolves |
| `License:` | SPDX identifier (e.g. `MIT`, `Apache-2.0`) or `see source` | Check 3: license match |
| `Install method:` | One of `npm-global`, `npx`, `claude-plugin-marketplace`, `mcp-config`, `homebrew`, `web-url`, `manual-copy` | Check 2: dispatches the registry check |
| `npm package:` | Package name on the npm registry (when applicable) | Check 2: `npm view <pkg>` exists |
| `Last verified:` | ISO date of last manual review | Check 4: <180 days |

The *Install* block is verbatim shell. The setup workflow runs it as-is. The *Verify* block is the smoke test. *Notes* is prose for the human reader.

**For maintainers editing this file.** When you bump an entry, refetch the upstream README and update the `Install:` block to match. Bump `Last verified:` to today. Don't paraphrase install steps — copy them.

---

## 1 · CORE — Context efficiency

Reduces per-turn token cost by keeping voluminous tool output out of the active context window.

### Implementation: context-mode

- **Source:** https://github.com/mksglu/context-mode
- **License:** Elastic-2.0 (source-available)
- **Install method:** `claude-plugin-marketplace` (Claude Code) or `npm-global` (other runtimes)
- **npm package:** `context-mode`
- **Last verified:** 2026-05-22

**Install (Claude Code, recommended):**

```
/plugin marketplace add mksglu/context-mode
```

**Install (all runtimes, npm):**

```bash
npm install -g context-mode
```

**Verify:**

```bash
context-mode --version
```

**Notes.** Requires Node.js 18+. Fully local — no API keys. After install on Claude Code, the `ctx-mode: $X saved · N% eff` statusline segment (see [README](../../README.md#-spectrum-super-powers)) lights up. Elastic 2.0 is source-available, not OSI open-source — review the license for commercial redistribution constraints.

---

## 2 · CORE — Version control & PR flow

A CLI for the host you push to. Picker asks which of GitHub / GitLab / Bitbucket matches your project before installing.

### Implementation A: GitHub CLI (`gh`)

- **Source:** https://github.com/cli/cli
- **License:** MIT
- **Install method:** `homebrew` (macOS), `winget` (Windows), or distro package (Linux)
- **Last verified:** 2026-05-21

**Install (macOS):**

```bash
brew install gh
```

**Install (Windows):**

```bash
winget install --id GitHub.cli
```

**Install (Linux):** see https://github.com/cli/cli/blob/trunk/docs/install_linux.md

**Post-install auth:**

```bash
gh auth login
```

**Verify:**

```bash
gh auth status
```

### Implementation B: GitLab CLI (`glab`)

- **Source:** https://gitlab.com/gitlab-org/cli
- **License:** MIT
- **Install method:** `homebrew` (macOS) or distro package
- **Last verified:** 2026-05-21

**Install (macOS):**

```bash
brew install glab
```

**Install (other OS):** see https://gitlab.com/gitlab-org/cli#installation

**Post-install auth:**

```bash
glab auth login
```

**Verify:**

```bash
glab auth status
```

### Implementation C: Bitbucket CLI (gap — pick at install time)

- **Source:** *no first-party Atlassian CLI exists; the picker prompts the user to choose a community option*
- **License:** depends on choice
- **Install method:** `manual-copy` (deferred to user choice)
- **Last verified:** 2026-05-22

**Install.** The picker prompts the user. Choices typically include:
- Stick with `git` + browser (the simplest option for ad-hoc work)
- A community CLI (e.g. `bb` from gentlecorp-tech)
- Python-based clients like `pybitbucket` if scripting is needed

Whichever the user picks, fetch the upstream install steps from that project's README and run them. Bitbucket uses app passwords, not OAuth device flow for CLI clients.

**Notes.** Revisit if Atlassian releases a first-party `gh`-equivalent.

---

## 3 · PERSONA — UI/UX design system generation

Generates professional UI and design-system scaffolding across platforms. *Personas: Designer, FDE.*

### Implementation: ui-ux-pro-max-skill

- **Source:** https://github.com/nextlevelbuilder/ui-ux-pro-max-skill
- **License:** MIT
- **Install method:** `claude-plugin-marketplace` (recommended) or `npm-global` (via `uipro-cli`)
- **npm package:** `uipro-cli`
- **Last verified:** 2026-05-22

**Install (Claude Code marketplace, recommended):**

```
/plugin marketplace add nextlevelbuilder/ui-ux-pro-max-skill
/plugin install ui-ux-pro-max@ui-ux-pro-max-skill
```

**Install (CLI, alternative — works without the marketplace):**

```bash
npm install -g uipro-cli
uipro init --ai claude --global
```

**Verify:**

```bash
uipro --version
```

**Notes.** Python 3.x required for the search script. CLI install lands at `~/.claude/skills/`; marketplace install lands at `.claude/plugins/`. Pick the CLI path if you want global access across all projects; pick the marketplace path if you prefer the Claude Code-native plugin lifecycle.

---

## 4 · PERSONA — Frontend design audit & live styling

23 commands under the `/impeccable` prefix for design-system intelligence and live styling guidance. *Personas: Designer, FDE.*

### Implementation: impeccable-style

- **Source:** https://github.com/pbakaus/impeccable
- **License:** Apache-2.0
- **Install method:** `manual-copy` (download bundle, copy into `.claude/`)
- **Last verified:** 2026-05-22

**Install (global, recommended):**

```bash
# 1. Download the pre-built bundle from https://impeccable.style
#    (or clone the repo and use dist/claude-code/.claude as the source)
# 2. Merge into your user .claude directory:
cp -r dist/claude-code/.claude/* ~/.claude/
```

**Install (project-scoped):**

```bash
cp -r dist/claude-code/.claude your-project/
```

**Verify.** Restart Claude Code, then `/impeccable audit` should be available as a slash command.

**Notes.** No npm package, no plugin marketplace. The author ships pre-built bundles on https://impeccable.style — that's the canonical distribution. After install, the 23 commands live under the `/impeccable` namespace.

---

## 5 · PERSONA — Collaborative diagramming

Hand-drawn-style virtual whiteboard for wireframes, flowcharts, and architecture sketches. *Personas: Designer, Architect, BA/PM.*

### Implementation: Excalidraw

- **Source:** https://excalidraw.com
- **License:** MIT (https://github.com/excalidraw/excalidraw)
- **Install method:** `web-url`
- **Last verified:** 2026-05-21

**Install.** Nothing to install. Open https://excalidraw.com in a browser.

**Verify.** The page loads with a blank canvas.

**Notes.** For a self-hosted instance, clone https://github.com/excalidraw/excalidraw and follow that repo's README. The hosted version covers ~all use cases.

---

## 6 · PERSONA — Browser automation

Drive a real browser from agent code. Picker asks which of agent-browser / Playwright matches your stack before installing.

### Implementation A: agent-browser

- **Source:** https://github.com/vercel-labs/agent-browser
- **License:** Apache-2.0
- **Install method:** `npm-global`
- **npm package:** `agent-browser`
- **Last verified:** 2026-05-22

**Install:**

```bash
npm install -g agent-browser
agent-browser install
```

The second command downloads Chrome for Testing (Google's automation channel). On macOS you can substitute with Homebrew:

```bash
brew install agent-browser
agent-browser install
```

**Verify:**

```bash
agent-browser open example.com
agent-browser snapshot
```

**Notes.** Pure CLI (Rust binary), not an MCP server. Chrome for Testing is bundled by `agent-browser install`, but you can point at an existing Chrome/Brave/Chromium with `--executable-path`. Optional auth via `agent-browser auth save`.

### Implementation B: Playwright

- **Source:** https://playwright.dev
- **License:** Apache-2.0 (https://github.com/microsoft/playwright)
- **Install method:** `npm-global` (via `npm init playwright`)
- **npm package:** `@playwright/test`
- **Last verified:** 2026-05-21

**Install (from project root):**

```bash
npm init playwright@latest
```

Accept the prompts (TypeScript or JavaScript, test directory, GitHub Actions if desired). The installer downloads the Chromium/Firefox/WebKit binaries.

**Verify:**

```bash
npx playwright test --list
```

**Notes.** Pick Playwright if your project is Next.js, React, or any web stack you're already testing. Pick agent-browser for pure-agent workflows where Chrome control is the goal.

---

## 7 · PERSONA — HTML-to-video rendering

Renders HTML/CSS/JS into video clips for demos, walkthroughs, and marketing reels. *Personas: Designer, FDE.*

### Implementation: hyperframes

- **Source:** https://github.com/heygen-com/hyperframes
- **License:** Apache-2.0
- **Install method:** `npx` (no global install needed)
- **npm package:** `hyperframes`
- **Last verified:** 2026-05-22

**Install (per-project, recommended):**

```bash
npx hyperframes init my-video
cd my-video
```

**Add the agent skill (optional, for agent-driven rendering):**

```bash
npx skills add heygen-com/hyperframes
```

**Verify:**

```bash
npx hyperframes preview     # should open browser preview
npx hyperframes render      # should generate output.mp4
```

**Notes.** Requires Node 22+ and FFmpeg on PATH. Designed for non-interactive agent use — `npx hyperframes render` is the canonical "build a video" command. Pure Apache-2.0, unrestricted commercial use.

---

## Validation contract

`/spec-validate-extras` runs four cheap checks against every entry:

1. **Source URL resolves** — HTTP 200 (or 30x to a 200) on the URL in the `Source:` field.
2. **Registry check** — dispatched by `Install method:`
   - `npm-global` / `npx` → `npm view <npm-package>` succeeds
   - `claude-plugin-marketplace` → source URL resolves (the plugin registry is not remotely probeable)
   - `homebrew` → `brew info <formula>` succeeds (when `brew` is on PATH)
   - `mcp-config` / `web-url` / `manual-copy` → source URL resolves (no registry to probe)
3. **License match** — if `License:` is filled, fetch the source URL and confirm the SPDX identifier appears. `see source` and `depends on choice` skip silently.
4. **Last-verified freshness** — entries older than 180 days emit `⚠`.

Failures emit `✗`. Warnings (stale `Last verified:`, missing license) emit `⚠`. Otherwise `✓`.

Run `/spec-validate-extras` quarterly. Run it before a release.
