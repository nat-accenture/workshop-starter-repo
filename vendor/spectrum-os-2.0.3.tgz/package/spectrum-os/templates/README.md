# spectrumOS Canonical Artifact Registry

This directory contains the template files for every artifact that spectrumOS workflows officially produce. The table below is the authoritative index: **if a `.planning/` root file is not listed here, `spec-health` will flag it as W019** (unrecognized artifact).

Agents should query this file before treating a `.planning/` file as authoritative. If the file name does not appear below, it is not a canonical spectrumOS artifact.

---

## `.planning/` Root Artifacts

These files live directly at `.planning/` — not inside phase subdirectories.

| File | Template | Produced by | Purpose |
|------|----------|-------------|---------|
| `PROJECT.md` | `project.md` | `/spec-new-project` | Project identity, goals, requirements summary |
| `ROADMAP.md` | `roadmap.md` | `/spec-new-milestone`, `/spec-new-project` | Phase plan with milestones and progress tracking |
| `STATE.md` | `state.md` | `/spec-new-project`, `/spec-health --repair` | Current session state, active phase, last activity |
| `REQUIREMENTS.md` | `requirements.md` | `/spec-new-milestone` | Functional requirements with traceability |
| `MILESTONES.md` | `milestone.md` | `/spec-complete-milestone` | Log of completed milestones with accomplishments |
| `BACKLOG.md` | *(inline)* | `/spec-add-backlog` | Pending ideas and deferred work |
| `LEARNINGS.md` | *(inline)* | `/spec-extract-learnings`, `/spec-execute-phase` | Phase retrospective learnings for future plans |
| `THREADS.md` | *(inline)* | `/spec-thread` | Persistent discussion threads |
| `config.json` | `config.json` | `/spec-new-project`, `/spec-health --repair` | Project-specific spectrumOS configuration |
| `CLAUDE.md` | `claude-md.md` | `/spec-profile` | Auto-assembled Claude Code context file |
| `RETROSPECTIVE.md` | *(inline)* | `/spec-complete-milestone` | Living milestone retrospective updated at each milestone close |

### Version-stamped artifacts (pattern: `vX.Y-*.md`)

| Pattern | Produced by | Purpose |
|---------|-------------|---------|
| `vX.Y-MILESTONE-AUDIT.md` | `/spec-audit-milestone` | Milestone audit report before archiving |

These files are archived to `.planning/milestones/` by `/spec-complete-milestone`. Finding them at the `.planning/` root after completion indicates the archive step was skipped.

---

## Phase Subdirectory Artifacts (`.planning/phases/NN-name/`)

These files live inside a phase directory. They are NOT checked by W019 (which only inspects the `.planning/` root).

| File Pattern | Template | Produced by | Purpose |
|-------------|----------|-------------|---------|
| `NN-MM-PLAN.md` | `phase-prompt.md` | `/spec-plan-phase` | Executable implementation plan |
| `NN-MM-SUMMARY.md` | `summary.md` | `/spec-execute-phase` | Post-execution summary with learnings |
| `NN-CONTEXT.md` | `context.md` | `/spec-discuss-phase` | Scoped discussion decisions for the phase |
| `NN-RESEARCH.md` | `research.md` | `/spec-plan-phase`, `/spec-plan-phase --research-phase <N>` | Technical research for the phase |
| `NN-VALIDATION.md` | `VALIDATION.md` | `/spec-plan-phase` (Nyquist) | Validation architecture (Nyquist method) |
| `NN-UAT.md` | `UAT.md` | `/spec-validate-phase` | User acceptance test results |
| `NN-PATTERNS.md` | *(inline)* | `/spec-plan-phase` (pattern mapper) | Analog file mapping for the phase |
| `NN-UI-SPEC.md` | `UI-SPEC.md` | `/spec-ui-phase` | UI design contract |
| `NN-SECURITY.md` | `SECURITY.md` | `/spec-secure-phase` | Security threat model |
| `NN-AI-SPEC.md` | `AI-SPEC.md` | `/spec-ai-integration-phase` | AI integration spec with eval strategy |
| `NN-DEBUG.md` | `DEBUG.md` | `/spec-debug` | Debug session log |
| `NN-REVIEWS.md` | *(inline)* | `/spec-review` | Cross-AI review feedback |

---

## Milestone Archive (`.planning/milestones/`)

Files archived by `/spec-complete-milestone`. These are never checked by W019.

| File Pattern | Source |
|-------------|--------|
| `vX.Y-ROADMAP.md` | Snapshot of ROADMAP.md at milestone close |
| `vX.Y-REQUIREMENTS.md` | Snapshot of REQUIREMENTS.md at milestone close |
| `vX.Y-MILESTONE-AUDIT.md` | Moved from `.planning/` root |
| `vX.Y-phases/` | Archived phase directories (if `--archive-phases` used) |

---

## Adding a New Canonical Artifact

When a new workflow produces a `.planning/` root file:

1. Add the file name to `CANONICAL_EXACT` in `spectrum-os/bin/lib/artifacts.cjs`
2. Add a row to the **`.planning/` Root Artifacts** table above
3. Add the template to `spectrum-os/templates/` if one exists
