# Instructions for spectrumOS

- Use the spectrum-os skill when the user asks for spectrumOS or uses a `spec-*` command.
- Treat `/spec-...` or `spec-...` as command invocations and load the matching file from `.github/skills/spec-*`.
- When a command says to spawn a subagent, prefer a matching custom agent from `.github/agents`.
- Do not apply spectrumOS workflows unless the user explicitly asks for them.
- After completing any `spec-*` command (or any deliverable it triggers: feature, bug fix, tests, docs, etc.), ALWAYS: (1) offer the user the next step by prompting via `ask_user`; repeat this feedback loop until the user explicitly indicates they are done.
