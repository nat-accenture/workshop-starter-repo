<purpose>
Display the complete spectrumOS command reference. Output ONLY the reference content. The single permitted modification is the version line in the banner: replace the literal token {{VERSION}} with the contents of ~/.claude/spectrum-os/VERSION. If that file is missing or unreadable, render the banner without the version line. Do NOT add project-specific analysis, git status, next-step suggestions, or any other commentary beyond the reference.
</purpose>

<reference>
```
███████╗██████╗ ███████╗ ██████╗
██╔════╝██╔══██╗██╔════╝██╔════╝
███████╗██████╔╝█████╗  ██║
╚════██║██╔═══╝ ██╔══╝  ██║
███████║██║     ███████╗╚██████╗
╚══════╝╚═╝     ╚══════╝ ╚═════╝

spectrumOS  ·  v{{VERSION}}
```

# spectrumOS Command Reference

**spectrumOS** is an AI harness for Claude Code, Codex, Gemini, and Copilot. It creates hierarchical, spec-driven project plans for both solo and team agentic development.

## Quick Start

1. `/spec-new-project` - Initialize project (includes research, requirements, roadmap)
2. `/spec-plan-phase 1` - Create detailed plan for first phase
3. `/spec-execute-phase 1` - Execute the phase

## Team Setup — Developer-Name Tracking

By default spectrumOS numbers phases plainly (`01-auth`). On a team, turn on **owner-namespaced phases** so each person's work carries their git-derived handle and never collides.

1. Set your git identity (your handle is derived from it):

```bash
git config user.email "you@example.com"
git config user.name "Your Name"
```

2. Enable namespacing in the project's `.planning/config.json`:

```json
{ "phase_namespacing": true }
```

New phases are then named `<handle>-NN-slug` (e.g. `kd-01-auth`), so `kd-01` and `mira-01` coexist with no coordination. Solo projects keep plain numbers (the prefix is display-collapsed). If git identity is unset while namespacing is on, the tool stops and asks you to set it rather than guessing.

**One owner per feature**, so two people never build the same thing at once:

```bash
spec-sdk query ownership.claim <feature>     # take exclusive ownership
spec-sdk query ownership.status              # who owns what right now
spec-sdk query ownership.publish <feature>   # hand it back to the team
```

`.planning/` is committed to git, so this context travels with the repo for everyone.

## Roles — How Each Persona Uses spectrumOS

Five characters, one harness. Pick the flow that matches your role.

- **🎨 Designer:** prototype + design-review prep
  `/spec-sketch` → `/spec-ui-phase` → `/spec-mvp-phase` → `/spec-ui-review`
- **🏛️ Architect:** understand the domain, map code, frame the build
  `/spec-map-codebase` → `/spec-explore` → `/spec-discuss-phase` → `/spec-spec-phase`
- **🚀 Forward Deployed Engineer:** execute fast, debug, ship
  `/spec-execute-phase` · `/spec-quick` · `/spec-fast` · `/spec-debug` · `/spec-ship`
- **✅ UAT Tester:** walk every requirement, prove it works
  `/spec-verify-work` · `/spec-validate-phase` · `/spec-audit-uat` · `/spec-add-tests`
- **📋 BA / PM:** status, what's blocked, what's next
  `/spec-progress` · `/spec-stats` · `/spec-audit-milestone` · `/spec-milestone-summary`

## Staying Updated

When a newer `spectrum-os-<version>.tgz` is released, you'll be given the file. Install it the same way as the first time:

```bash
npm install -g spectrum-os-<version>.tgz
spectrum-os
```

Upgrading is overwrite-in-place: the framework is redeployed and your projects' `.planning/` data is left untouched, so there's no migration step.

## Core Workflow

```
/spec-new-project → /spec-plan-phase → /spec-execute-phase → repeat
```

### Project Initialization

**`/spec-new-project`**
Initialize new project through unified flow.

One command takes you from idea to ready-for-planning:
- Deep questioning to understand what you're building
- Optional domain research (spawns 4 parallel researcher agents)
- Requirements definition with v1/v2/out-of-scope scoping
- Roadmap creation with phase breakdown and success criteria

Creates all `.planning/` artifacts:
- `PROJECT.md` — vision and requirements
- `config.json` — workflow mode (interactive/yolo)
- `research/` — domain research (if selected)
- `REQUIREMENTS.md` — scoped requirements with REQ-IDs
- `ROADMAP.md` — phases mapped to requirements
- `STATE.md` — project memory

Usage: `/spec-new-project`

**`/spec-map-codebase [--fast] [--focus <area>] [--query <term>]`**
Map an existing codebase for brownfield projects.

- `--fast` — rapid lightweight assessment (replaces the former `spec-scan`)
- `--focus <area>` — scope the map to a specific area
- `--query <term>` — query the codebase intelligence index in `.planning/intel/` (replaces the former `spec-intel`)

- Analyzes codebase with parallel Explore agents
- Creates `.planning/codebase/` with 7 focused documents
- Covers stack, architecture, structure, conventions, testing, integrations, concerns
- Use before `/spec-new-project` on existing codebases

Usage: `/spec-map-codebase`

### Phase Planning

**`/spec-discuss-phase <number> [--chain | --analyze | --power | --assumptions] [--batch[=N]]`**
Help articulate your vision for a phase before planning.

- `--chain` — chained-prompt discuss flow
- `--analyze` — deep assumption analysis pass
- `--power` — power-user mode with extended question set
- `--assumptions` — surface Claude's implementation assumptions about the phase without an interactive session

- Captures how you imagine this phase working
- Creates CONTEXT.md with your vision, essentials, and boundaries
- Use when you have ideas about how something should look/feel
- Optional `--batch` asks 2-5 related questions at a time instead of one-by-one

Usage: `/spec-discuss-phase 2`
Usage: `/spec-discuss-phase 2 --batch`
Usage: `/spec-discuss-phase 2 --batch=3`

**`/spec-mvp-phase <number> [--force]`**
Plan a phase as a vertical MVP slice — three structured user-story prompts (`As a / I want to / So that`), SPIDR splitting if the story is too large, then delegates to `/spec-plan-phase` with MVP mode active.

- Mutates the phase's ROADMAP entry: writes `**Mode:** mvp` + replaces `**Goal:**` with the assembled user story
- Validates the story via `spec-sdk query user-story.validate` (canonical regex `/^As a .+, I want to .+, so that .+\.$/`)
- `--force` overrides the status guard (required if the phase is already `in_progress` or `completed`)
- Pairs with the new-project mode prompt (Vertical MVP vs Horizontal Layers)

Usage: `/spec-mvp-phase 1`
Usage: `/spec-mvp-phase 2 --force`

**`/spec-plan-phase <number> [--research] [--skip-research] [--research-phase <N>] [--view] [--gaps] [--skip-verify] [--tdd] [--mvp]`**
Create detailed execution plan for a specific phase.

- `--skip-research` — bypass the research subagent
- `--research-phase <N>` — research-only mode. Spawns the research agent for phase `<N>`, writes `RESEARCH.md`, then exits before the planner runs. Useful for cross-phase research, doc review before committing to a planning approach, and correction-without-replanning loops. Replaces the deleted `spec-research-phase` standalone command (#3042).
  - Modifiers: `--research` forces refresh (re-spawn researcher, no prompt). `--view` prints existing `RESEARCH.md` to stdout without spawning. With neither, prompts `update / view / skip` if `RESEARCH.md` already exists.
- `--gaps` — focus only on closing gaps from a prior plan-check
- `--skip-verify` — skip the post-plan verifier loop
- `--tdd` — plan in test-driven order (tests before code)
- `--mvp` — vertical-slice MVP planning mode

- Generates `.planning/phases/XX-phase-name/XX-YY-PLAN.md`
- Breaks phase into concrete, actionable tasks
- Includes verification criteria and success measures
- Multiple plans per phase supported (XX-01, XX-02, etc.)

Usage: `/spec-plan-phase 1`
Usage: `/spec-plan-phase --research-phase 2` — research only on phase 2 (prompts if `RESEARCH.md` exists)
Usage: `/spec-plan-phase --research-phase 2 --view` — print existing `RESEARCH.md`, no spawn
Usage: `/spec-plan-phase --research-phase 2 --research` — force-refresh, no prompt
Result: Creates `.planning/phases/01-foundation/01-01-PLAN.md`

**PRD Express Path:** Pass `--prd path/to/requirements.md` to skip discuss-phase entirely. Your PRD becomes locked decisions in CONTEXT.md. Useful when you already have clear acceptance criteria.

### Execution

**`/spec-execute-phase <phase-number> [--wave N] [--gaps-only] [--tdd]`**
Execute all plans in a phase, or run a specific wave.

- `--wave N` — execute only wave N (see *Plans within each wave* below)
- `--gaps-only` — re-run only plans flagged as gaps by a prior verifier
- `--tdd` — enforce test-driven order during execution

- Groups plans by wave (from frontmatter), executes waves sequentially
- Plans within each wave run in parallel via Task tool
- Optional `--wave N` flag executes only Wave `N` and stops unless the phase is now fully complete
- Verifies phase goal after all plans complete
- Updates REQUIREMENTS.md, ROADMAP.md, STATE.md

Usage: `/spec-execute-phase 5`
Usage: `/spec-execute-phase 5 --wave 2`

### Smart Router

**`/spec-progress --do "<description>"`**
Route freeform text to the right spectrumOS command automatically.

- Analyzes natural language input to find the best matching spectrumOS command
- Acts as a dispatcher — never does the work itself
- Resolves ambiguity by asking you to pick between top matches
- Use when you know what you want but don't know which `/spec-*` command to run

Usage: `/spec-progress --do "fix the login button"`
Usage: `/spec-progress --do "refactor the auth system"`
Usage: `/spec-progress --do "I want to start a new milestone"`

### Quick Mode

**`/spec-quick [--full] [--validate] [--discuss] [--research]`**
Execute small, ad-hoc tasks with spectrumOS guarantees but skip optional agents.

Quick mode uses the same system with a shorter path:
- Spawns planner + executor (skips researcher, checker, verifier by default)
- Quick tasks live in `.planning/quick/` separate from planned phases
- Updates STATE.md tracking (not ROADMAP.md)

Flags enable additional quality steps:
- `--full` — Complete quality pipeline: discussion + research + plan-checking + verification
- `--validate` — Plan-checking (max 2 iterations) and post-execution verification only
- `--discuss` — Lightweight discussion to surface gray areas before planning
- `--research` — Focused research agent investigates approaches before planning

Granular flags are composable: `--discuss --research --validate` gives the same as `--full`.

Usage: `/spec-quick`
Usage: `/spec-quick --full`
Usage: `/spec-quick --research --validate`
Result: Creates `.planning/quick/NNN-slug/PLAN.md`, `.planning/quick/NNN-slug/NNN-slug-SUMMARY.md`

---

**`/spec-fast [description]`**
Execute a trivial task inline — no subagents, no planning files, no overhead.

For tasks too small to justify planning: typo fixes, config changes, forgotten commits, simple additions. Runs in the current context, makes the change, commits, and logs to STATE.md.

- No PLAN.md or SUMMARY.md created
- No subagent spawned (runs inline)
- ≤ 3 file edits — redirects to `/spec-quick` if task is non-trivial
- Atomic commit with conventional message

Usage: `/spec-fast "fix the typo in README"`
Usage: `/spec-fast "add .env to gitignore"`

### Roadmap Management

**`/spec-phase <description>`**
Add new phase to end of current milestone.

- Appends to ROADMAP.md
- Uses next sequential number
- Updates phase directory structure

Usage: `/spec-phase "Add admin dashboard"`

**`/spec-phase --insert <after> <description>`**
Insert urgent work as decimal phase between existing phases.

- Creates intermediate phase (e.g., 7.1 between 7 and 8)
- Useful for discovered work that must happen mid-milestone
- Maintains phase ordering

Usage: `/spec-phase --insert 7 "Fix critical auth bug"`
Result: Creates Phase 7.1

**`/spec-phase --remove <number>`**
Remove a future phase and renumber subsequent phases.

- Deletes phase directory and all references
- Renumbers all subsequent phases to close the gap
- Only works on future (unstarted) phases
- Git commit preserves historical record

Usage: `/spec-phase --remove 17`
Result: Phase 17 deleted, phases 18-20 become 17-19

**`/spec-phase --edit <number> [--force]`**
Edit any field of an existing roadmap phase in place, preserving number and position.

- Updates title, description, requirements, dependencies in `ROADMAP.md`
- `--force` allows editing already-started phases (use with caution)

### Milestone Management

**`/spec-new-milestone <name>`**
Start a new milestone through unified flow.

- Deep questioning to understand what you're building next
- Optional domain research (spawns 4 parallel researcher agents)
- Requirements definition with scoping
- Roadmap creation with phase breakdown
- Optional `--reset-phase-numbers` flag restarts numbering at Phase 1 and archives old phase dirs first for safety

Mirrors `/spec-new-project` flow for brownfield projects (existing PROJECT.md).

Usage: `/spec-new-milestone "v2.0 Features"`
Usage: `/spec-new-milestone --reset-phase-numbers "v2.0 Features"`

**`/spec-complete-milestone <version>`**
Archive completed milestone and prepare for next version.

- Creates MILESTONES.md entry with stats
- Archives full details to milestones/ directory
- Creates git tag for the release
- Prepares workspace for next version

Usage: `/spec-complete-milestone 1.0.0`

### Progress Tracking

**`/spec-progress [--next | --forensic | --do "<description>"]`**
Check project status and intelligently route to next action.

- Shows visual progress bar and completion percentage
- Summarizes recent work from SUMMARY files
- Displays current position and what's next
- Lists key decisions and open issues
- Offers to execute next plan or create it if missing
- Detects 100% milestone completion

Modes:
- **default** — progress report + intelligent routing
- **`--next`** — auto-advance to the next logical step (use `--next --force` to bypass safety gates)
- **`--forensic`** — append a 6-check integrity audit after the progress report
- **`--do "<text>"`** — smart router: dispatch freeform intent to the matching `/spec-*` command (see *Smart Router* above)

Usage: `/spec-progress`
Usage: `/spec-progress --next`
Usage: `/spec-progress --forensic`

### Session Management

**`/spec-resume-work`**
Resume work from previous session with full context restoration.

- Reads STATE.md for project context
- Shows current position and recent progress
- Offers next actions based on project state

Usage: `/spec-resume-work`

**`/spec-pause-work [--report]`**
Create context handoff when pausing work mid-phase.

- `--report` — generate a post-session summary in `.planning/reports/` capturing commits, file changes, and phase progress
- Creates .continue-here file with current state
- Updates STATE.md session continuity section
- Captures in-progress work context

Usage: `/spec-pause-work`

### Debugging

**`/spec-debug [issue description] [--diagnose]`**
Systematic debugging with persistent state across context resets.

- `--diagnose` — run a one-shot diagnostic pass without opening a persistent debug session

- Gathers symptoms through adaptive questioning
- Creates `.planning/debug/[slug].md` to track investigation
- Investigates using scientific method (evidence → hypothesis → test)
- Survives `/clear` — run `/spec-debug` with no args to resume
- Archives resolved issues to `.planning/debug/resolved/`

Usage: `/spec-debug "login button doesn't work"`
Usage: `/spec-debug` (resume active session)

### Spiking & Sketching

**`/spec-spike [idea] [--quick]`**
Rapidly spike an idea with throwaway experiments to validate feasibility.

- Decomposes idea into 2-5 focused experiments (risk-ordered)
- Each spike answers one specific Given/When/Then question
- Builds minimum code, runs it, captures verdict (VALIDATED/INVALIDATED/PARTIAL)
- Saves to `.planning/spikes/` with MANIFEST.md tracking
- Does not require `/spec-new-project` — works in any repo
- `--quick` skips decomposition, builds immediately

Usage: `/spec-spike "can we stream LLM output over WebSockets?"`
Usage: `/spec-spike --quick "test if pdfjs extracts tables"`

**`/spec-sketch [idea] [--quick]`**
Rapidly sketch UI/design ideas using throwaway HTML mockups with multi-variant exploration.

- Conversational mood/direction intake before building
- Each sketch produces 2-3 variants as tabbed HTML pages
- User compares variants, cherry-picks elements, iterates
- Shared CSS theme system compounds across sketches
- Saves to `.planning/sketches/` with MANIFEST.md tracking
- Does not require `/spec-new-project` — works in any repo
- `--quick` skips mood intake, jumps to building

Usage: `/spec-sketch "dashboard layout for the admin panel"`
Usage: `/spec-sketch --quick "form card grouping"`

**`/spec-spike --wrap-up`**
Package spike findings into a persistent project skill.

- Curates each spike one-at-a-time (include/exclude/partial/UAT)
- Groups findings by feature area
- Generates `./.claude/skills/spike-findings-[project]/` with references and sources
- Writes summary to `.planning/spikes/WRAP-UP-SUMMARY.md`
- Adds auto-load routing line to project CLAUDE.md

Usage: `/spec-spike --wrap-up`

**`/spec-sketch --wrap-up`**
Package sketch design findings into a persistent project skill.

- Curates each sketch one-at-a-time (include/exclude/partial/revisit)
- Groups findings by design area
- Generates `./.claude/skills/sketch-findings-[project]/` with design decisions, CSS patterns, HTML structures
- Writes summary to `.planning/sketches/WRAP-UP-SUMMARY.md`
- Adds auto-load routing line to project CLAUDE.md

Usage: `/spec-sketch --wrap-up`

### Capturing Ideas, Notes, and Todos

**`/spec-capture [description]`**
Capture an idea or task as a structured todo from current conversation.

- Extracts context from conversation (or uses provided description)
- Creates structured todo file in `.planning/todos/pending/`
- Infers area from file paths for grouping
- Checks for duplicates before creating
- Updates STATE.md todo count

Usage: `/spec-capture` (infers from conversation)
Usage: `/spec-capture Add auth token refresh`

**`/spec-capture --note <text>`**
Zero-friction note capture — one command, instant save, no questions.

- Saves timestamped note to `.planning/notes/` (or `~/.claude/notes/` globally)
- Three subcommands: append (default), list, promote
- Promote converts a note into a structured todo
- Works without a project (falls back to global scope)

Usage: `/spec-capture --note refactor the hook system`
Usage: `/spec-capture --note list`
Usage: `/spec-capture --note promote 3`
Usage: `/spec-capture --note --global cross-project idea`

**`/spec-capture --list [area]`**
List pending todos and select one to work on.

- Lists all pending todos with title, area, age
- Optional area filter (e.g., `/spec-capture --list api`)
- Loads full context for selected todo
- Routes to appropriate action (work now, add to phase, brainstorm)
- Moves todo to done/ when work begins

Usage: `/spec-capture --list`
Usage: `/spec-capture --list api`

### User Acceptance Testing

**`/spec-verify-work [phase]`**
Validate built features through conversational UAT.

- Extracts testable deliverables from SUMMARY.md files
- Presents tests one at a time (yes/no responses)
- Automatically diagnoses failures and creates fix plans
- Ready for re-execution if issues found

Usage: `/spec-verify-work 3`

### Ship Work

**`/spec-ship [phase]`**
Create a PR from completed phase work with an auto-generated body.

- Pushes branch to remote
- Creates PR with summary from SUMMARY.md, VERIFICATION.md, REQUIREMENTS.md
- Optionally requests code review
- Updates STATE.md with shipping status

Prerequisites: Phase verified, `gh` CLI installed and authenticated.

Usage: `/spec-ship 4` or `/spec-ship 4 --draft`

---

**`/spec-review --phase N [--gemini] [--claude] [--codex] [--coderabbit] [--all]`**
Cross-AI peer review — invoke external AI CLIs to independently review phase plans.

- Detects available CLIs (gemini, claude, codex, coderabbit)
- Each CLI reviews plans independently with the same structured prompt
- CodeRabbit reviews the current git diff (not a prompt) — may take up to 5 minutes
- Produces REVIEWS.md with per-reviewer feedback and consensus summary
- Feed reviews back into planning: `/spec-plan-phase N --reviews`

Usage: `/spec-review --phase 3 --all`

---

**`/spec-pr-branch [target]`**
Create a clean branch for pull requests by filtering out .planning/ commits.

- Classifies commits: code-only (include), planning-only (exclude), mixed (include sans .planning/)
- Cherry-picks code commits onto a clean branch
- Reviewers see only code changes, no spectrumOS artifacts

Usage: `/spec-pr-branch` or `/spec-pr-branch main`

---

**`/spec-capture --seed [idea]`**
Capture a forward-looking idea with trigger conditions for automatic surfacing.

- Seeds preserve WHY, WHEN to surface, and breadcrumbs to related code
- Auto-surfaces during `/spec-new-milestone` when trigger conditions match
- Better than deferred items — triggers are checked, not forgotten

Usage: `/spec-capture --seed "add real-time notifications when we build the events system"`

**`/spec-capture --backlog [description]`**
Add an idea to the backlog parking lot for future milestones.

- Creates a backlog item under 999.x numbering in ROADMAP.md
- Reserves ideas without committing to the current milestone
- Surface and promote later via `/spec-review-backlog`

Usage: `/spec-capture --backlog "real-time notifications when events ship"`

---

**`/spec-audit-uat`**
Cross-phase audit of all outstanding UAT and verification items.
- Scans every phase for pending, skipped, blocked, and human_needed items
- Cross-references against codebase to detect stale documentation
- Produces prioritized human test plan grouped by testability
- Use before starting a new milestone to clear verification debt

Usage: `/spec-audit-uat`

### Milestone Auditing

**`/spec-audit-milestone [version]`**
Audit milestone completion against original intent.

- Reads all phase VERIFICATION.md files
- Checks requirements coverage
- Spawns integration checker for cross-phase wiring
- Creates MILESTONE-AUDIT.md with gaps and tech debt

Usage: `/spec-audit-milestone`

### Configuration

**`/spec-settings`**
Configure workflow toggles and model profile interactively.

- Toggle researcher, plan checker, verifier agents
- Select model profile (quality/balanced/budget/inherit)
- Updates `.planning/config.json`

Usage: `/spec-settings`

**`/spec-config [--profile <profile> | --advanced | --integrations]`**
Configure spectrumOS beyond the basic settings: model profile, advanced tuning, and third-party integrations.

- `--profile <profile>` — quick switch model profile (`quality | balanced | budget | inherit`)
- `--advanced` — power-user tuning: plan bounce, timeouts, branch templates, cross-AI execution (replaces the former `spec-settings-advanced`)
- `--integrations` — third-party API keys, code-review CLI routing, agent-skill injection (replaces the former `spec-settings-integrations`)

- `quality` — Opus everywhere except verification
- `balanced` — Opus for planning, Sonnet for execution (default)
- `budget` — Sonnet for writing, Haiku for research/verification
- `inherit` — Use current session model for all agents (OpenCode `/model`)

Usage: `/spec-config --profile budget`

### Utility Commands

**`/spec-cleanup`**
Archive accumulated phase directories from completed milestones.

- Identifies phases from completed milestones still in `.planning/phases/`
- Shows dry-run summary before moving anything
- Moves phase dirs to `.planning/milestones/v{X.Y}-phases/`
- Use after multiple milestones to reduce `.planning/phases/` clutter

Usage: `/spec-cleanup`

**`/spec-help`**
Show this command reference.

**`/spec-update [--sync] [--reapply]`**
Sync skills and reapply local patches after installing a new build.

- `--sync` — sync managed spectrumOS skills across runtime roots (replaces the former `spec-sync-skills`)
- `--reapply` — reapply your local modifications after an update (replaces the former `spec-reapply-patches`)

Note: this is a private distribution. New versions arrive as a `spectrum-os-<version>.tgz` you install (see *Staying Updated* above), not from a public registry.

Usage: `/spec-update`

## Additional Commands

The commands above cover the most common day-to-day flows. Every command listed here is also a live `/spec-*` slash command and is grouped by purpose.

### Discovery & Specification

- **`/spec-explore`** — Socratic ideation and idea routing. Think through ideas before committing to plans.
- **`/spec-spec-phase <phase> [--auto] [--text]`** — Clarify WHAT a phase delivers with ambiguity scoring; produces a SPEC.md before discuss-phase.
- **`/spec-ai-integration-phase [phase]`** — Generate an AI-SPEC.md design contract for phases that involve building AI systems.
- **`/spec-ui-phase [phase]`** — Generate UI design contract (UI-SPEC.md) for frontend phases.
- **`/spec-import --from <filepath>`** — Ingest external plans with conflict detection against project decisions.
- **`/spec-ingest-docs [path] [--mode new|merge] [--manifest <file>] [--resolve auto|interactive]`** — Bootstrap or merge a `.planning/` setup from existing ADRs, PRDs, SPECs, and docs in a repo.

### Planning & Execution

- **`/spec-ultraplan-phase [phase]`** — [BETA] Offload plan phase to Claude Code's ultraplan cloud; review in browser and import back.
- **`/spec-plan-review-convergence <phase> [--codex] [--gemini] [--claude] [--ollama] [--lm-studio] [--llama-cpp] [--all] [--text] [--ws <name>] [--max-cycles N]`** — Cross-AI plan convergence loop — replan with review feedback until no HIGH concerns remain. Supports both cloud reviewers (Codex/Gemini/Claude) and local model runtimes (Ollama, LM Studio, llama.cpp).
- **`/spec-autonomous [--from N] [--to N] [--only N] [--interactive]`** — Run all remaining phases autonomously: discuss → plan → execute per phase.

### Quality, Review & Verification

- **`/spec-code-review <phase> [--depth=quick|standard|deep] [--files file1,file2,...] [--fix [--all] [--auto]]`** — Review source files changed during a phase for bugs, security issues, and code quality problems.
- **`/spec-secure-phase [phase]`** — Retroactively verify threat mitigations for a completed phase.
- **`/spec-validate-phase [phase]`** — Retroactively audit and fill Nyquist validation gaps for a completed phase.
- **`/spec-ui-review [phase]`** — Retroactive 6-pillar visual audit of implemented frontend code.
- **`/spec-eval-review [phase]`** — Audit an executed AI phase's evaluation coverage and produce an EVAL-REVIEW.md remediation plan.
- **`/spec-audit-fix --source <audit-uat> [--severity medium|high|all] [--max N] [--dry-run]`** — Autonomous audit-to-fix pipeline: find issues, classify, fix, test, commit.
- **`/spec-add-tests <phase> [additional instructions]`** — Generate tests for a completed phase based on UAT criteria and implementation.

### Diagnostics & Maintenance

- **`/spec-health [--repair] [--context]`** — Diagnose planning directory health and optionally repair issues.
- **`/spec-forensics [problem description]`** — Post-mortem investigation for failed spectrumOS workflows; diagnoses what went wrong.
- **`/spec-undo --last N | --phase NN | --plan NN-MM`** — Safe git revert. Roll back phase or plan commits using the phase manifest with dependency checks.
- **`/spec-docs-update [--force] [--verify-only]`** — Generate or update project documentation verified against the codebase.
- **`/spec-extract-learnings <phase>`** — Extract decisions, lessons, patterns, and surprises from completed phase artifacts.

### Knowledge & Context

- **`/spec-graphify [build|query <term>|status|diff]`** — Build, query, and inspect the project knowledge graph in `.planning/graphs/`.
- **`/spec-thread [list [--open|--resolved] | close <slug> | status <slug> | name | description]`** — Manage persistent context threads for cross-session work.
- **`/spec-profile-user [--questionnaire] [--refresh]`** — Generate developer behavioral profile and create Claude-discoverable artifacts.
- **`/spec-stats`** — Display project statistics: phases, plans, requirements, git metrics, and timeline.

### Workflow & Orchestration

- **`/spec-manager [--analyze-deps]`** — Interactive command center for managing multiple phases from one terminal. `--analyze-deps` scans ROADMAP phases for dependency relationships before parallel execution.
- **`/spec-workspace [--new | --list | --remove] [name]`** — Manage spectrumOS workspaces: create, list, or remove isolated workspace environments.
- **`/spec-workstreams`** — Manage parallel workstreams: list, create, switch, status, progress, complete, and resume.
- **`/spec-review-backlog`** — Review and promote backlog items to active milestone.
- **`/spec-milestone-summary [version]`** — Generate a comprehensive project summary from milestone artifacts for team onboarding and review.

### Repository Integration

- **`/spec-inbox [--issues] [--prs] [--label] [--close-incomplete] [--repo owner/repo]`** — Triage and review open GitHub issues and PRs against project templates and contribution guidelines.

### Namespace Routers (model-facing meta-skills)

These six skills exist primarily for the model to perform two-stage hierarchical routing across 60+ skills. You can invoke them directly when you want to browse a category interactively.

- **`/spec-context`** — Codebase intelligence routing (map, graphify, docs, learnings).
- **`/spec-ideate`** — Exploration / capture routing (explore, sketch, spike, spec, capture).
- **`/spec-manage`** — Configuration and workspace routing (workstreams, thread, update, ship, inbox).
- **`/spec-project`** — Project-lifecycle routing (milestones, audits, summary).
- **`/spec-review`** — Quality-gate routing (code review, debug, audit, security, eval, ui).
- **`/spec-workflow`** — Phase-pipeline routing (discuss, plan, execute, verify, phase, progress).

## Files & Structure

```
.planning/
├── PROJECT.md            # Project vision
├── ROADMAP.md            # Current phase breakdown
├── STATE.md              # Project memory & context
├── RETROSPECTIVE.md      # Living retrospective (updated per milestone)
├── config.json           # Workflow mode & gates
├── todos/                # Captured ideas and tasks
│   ├── pending/          # Todos waiting to be worked on
│   └── done/             # Completed todos
├── spikes/               # Spike experiments (/spec-spike)
│   ├── MANIFEST.md       # Spike inventory and verdicts
│   └── NNN-name/         # Individual spike directories
├── sketches/             # Design sketches (/spec-sketch)
│   ├── MANIFEST.md       # Sketch inventory and winners
│   ├── themes/           # Shared CSS theme files
│   └── NNN-name/         # Individual sketch directories (HTML + README)
├── debug/                # Active debug sessions
│   └── resolved/         # Archived resolved issues
├── milestones/
│   ├── v1.0-ROADMAP.md       # Archived roadmap snapshot
│   ├── v1.0-REQUIREMENTS.md  # Archived requirements
│   └── v1.0-phases/          # Archived phase dirs (via /spec-cleanup or --archive-phases)
│       ├── 01-foundation/
│       └── 02-core-features/
├── codebase/             # Codebase map (brownfield projects)
│   ├── STACK.md          # Languages, frameworks, dependencies
│   ├── ARCHITECTURE.md   # Patterns, layers, data flow
│   ├── STRUCTURE.md      # Directory layout, key files
│   ├── CONVENTIONS.md    # Coding standards, naming
│   ├── TESTING.md        # Test setup, patterns
│   ├── INTEGRATIONS.md   # External services, APIs
│   └── CONCERNS.md       # Tech debt, known issues
└── phases/
    ├── 01-foundation/
    │   ├── 01-01-PLAN.md
    │   └── 01-01-SUMMARY.md
    └── 02-core-features/
        ├── 02-01-PLAN.md
        └── 02-01-SUMMARY.md
```

## Workflow Modes

Set during `/spec-new-project`:

**Interactive Mode**

- Confirms each major decision
- Pauses at checkpoints for approval
- More guidance throughout

**YOLO Mode**

- Auto-approves most decisions
- Executes plans without confirmation
- Only stops for critical checkpoints

Change anytime by editing `.planning/config.json`

## Planning Configuration

Configure how planning artifacts are managed in `.planning/config.json`:

**`planning.commit_docs`** (default: `true`)
- `true`: Planning artifacts committed to git (standard workflow)
- `false`: Planning artifacts kept local-only, not committed

When `commit_docs: false`:
- Add `.planning/` to your `.gitignore`
- Useful for OSS contributions, client projects, or keeping planning private
- All planning files still work normally, just not tracked in git

**`planning.search_gitignored`** (default: `false`)
- `true`: Add `--no-ignore` to broad ripgrep searches
- Only needed when `.planning/` is gitignored and you want project-wide searches to include it

Example config:
```json
{
  "planning": {
    "commit_docs": false,
    "search_gitignored": true
  }
}
```

## Common Workflows

**Starting a new project:**

```
/spec-new-project        # Unified flow: questioning → research → requirements → roadmap
/clear
/spec-plan-phase 1       # Create plans for first phase
/clear
/spec-execute-phase 1    # Execute all plans in phase
```

**Resuming work after a break:**

```
/spec-progress  # See where you left off and continue
```

**Adding urgent mid-milestone work:**

```
/spec-phase --insert 5 "Critical security fix"
/spec-plan-phase 5.1
/spec-execute-phase 5.1
```

**Completing a milestone:**

```
/spec-complete-milestone 1.0.0
/clear
/spec-new-milestone  # Start next milestone (questioning → research → requirements → roadmap)
```

**Capturing ideas during work:**

```
/spec-capture                                  # Capture from conversation context
/spec-capture Fix modal z-index                # Capture with explicit description
/spec-capture --note refactor auth system      # Quick friction-free note
/spec-capture --seed "real-time notifications" # Forward-looking idea with triggers
/spec-capture --list                           # Review and work on todos
/spec-capture --list api                       # Filter by area
```

**Debugging an issue:**

```
/spec-debug "form submission fails silently"  # Start debug session
# ... investigation happens, context fills up ...
/clear
/spec-debug                                    # Resume from where you left off
```

## Getting Help

- Read `.planning/PROJECT.md` for project vision
- Read `.planning/STATE.md` for current context
- Check `.planning/ROADMAP.md` for phase status
- Run `/spec-progress` to check where you're up to
</reference>
