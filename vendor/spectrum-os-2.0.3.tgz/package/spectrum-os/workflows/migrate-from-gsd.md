# Workflow: Migrate from GSD to spectrum-os

One-shot scan + rewrite of a project's `.planning/` tree and `CLAUDE.md`. Converts GSD framework references to their spectrum-os equivalents. Honest about what can and cannot be auto-resolved.

After the safe-rewrite zone is handled, the workflow also scans the **rest of the repo** with smart ignores and lists any additional GSD references found (in `docs/`, `README.md`, source code, tests, CI configs, etc.). These are **never** auto-rewritten — the report shows file:line + suggested action so you can review and edit by hand.

---

## Step 1 — Resolve project path

- Parse `$ARGUMENTS` for the first non-flag token. Use as `<project-path>`. Default: current working directory.
- Parse flags: `--apply`, `--report-only`. If both present, `--report-only` wins.
- Determine mode:
  - `--apply` → **APPLY** mode
  - `--report-only` → **REPORT-ONLY** mode
  - else → **DRY-RUN** mode (default)

Verify `<project-path>/.planning/` exists. If not, exit with:

> No `.planning/` directory found at `<project-path>`. Nothing to migrate.

---

## Step 2 — Detect GSD markers

Run a single grep across `.planning/` and the root `CLAUDE.md`:

```bash
grep -rnE "/gsd:[a-z-]+|gsd-tools|get-shit-done|gsd-file-manifest" \
  "<project-path>/.planning/" \
  "<project-path>/CLAUDE.md" 2>/dev/null
```

Collect all hits as `(file, line, matched-text)` tuples.

If zero hits: continue to Step 2.5 anyway (broad scan may still find references outside the safe-rewrite zone). Only exit early if Step 2 AND Step 2.5 both return zero.

---

## Step 2.5 — Broad scan (outside the safe-rewrite zone)

After the primary scan, do a second pass across the rest of the repo with smart ignores. These hits are **never auto-rewritten** — they're surfaced in the report for manual review.

```bash
grep -rnIE "/gsd:[a-z-]+|gsd-tools|get-shit-done|gsd-file-manifest" \
  "<project-path>" \
  --exclude-dir=.git \
  --exclude-dir=node_modules \
  --exclude-dir=dist \
  --exclude-dir=build \
  --exclude-dir=.next \
  --exclude-dir=coverage \
  --exclude-dir=.planning \
  --exclude=CLAUDE.md \
  --exclude=migration-report.md \
  2>/dev/null
```

Notes:
- `-I` skips binary files
- `.planning/` and `CLAUDE.md` are excluded because Step 2 already covered them
- `migration-report.md` is excluded so re-runs don't pick up the report's own references
- Standard build directories (`dist`, `build`, `.next`, `coverage`) are ignored — they're generated artifacts

Collect these hits as **out-of-zone-refs**. Classify each using the same rules as Step 3, but always route to the report — never the safe-rewrite bucket.

If both Step 2 and Step 2.5 return zero hits: exit with:

> No GSD markers found at `<project-path>`. Project is already clean.

---

## Step 3 — Classify hits

For each hit:

1. **Path/binary refs** (`gsd-tools`, `get-shit-done`, `gsd-file-manifest`) → **safe-rewrite** bucket.
2. **Command refs** (`/gsd:<slug>`):
   - Extract `<slug>` (e.g. `plan-phase`, `do`, `add-backlog`).
   - If `<slug>` is in the **unresolved set** (below) → **unresolved** bucket with a suggested action.
   - Otherwise → **safe-rewrite** bucket as `/spec-<slug>`.

### Unresolved set (20 slugs)

```
do
plant-seed
note
add-todo
add-backlog
next
session-report
set-profile
list-phase-assumptions
reapply-patches
join-discord
research-phase
plan-milestone-gaps
check-todos
add-phase
insert-phase
remove-phase
new-workspace
remove-workspace
list-workspaces
```

### Suggested actions for unresolved slugs

| GSD slug | Suggested human action |
|---|---|
| `do` | Pick `/spec-quick` (urgent one-off, scoped smaller than a phase) or `/spec-fast` (trivial inline work). |
| `plant-seed` / `add-backlog` / `note` / `add-todo` | Use `/spec-capture` or `/spec-inbox` — these consolidate capture flows. |
| `next` / `check-todos` | Use `/spec-progress` (with `--next` for the auto-advance flavor). |
| `session-report` | No direct equivalent; consider manually writing a status note or using `/spec-stats`. |
| `set-profile` | Use `/spec-settings` to manage model profile. |
| `list-phase-assumptions` | No equivalent; assumptions are gathered during `/spec-discuss-phase` instead. |
| `reapply-patches` | No equivalent; framework upgrades use `node bin/install.js` re-runs. |
| `join-discord` | No equivalent — spectrum-os has no community channel today. |
| `research-phase` | Folded into `/spec-plan-phase` (research happens automatically in the plan pipeline). |
| `plan-milestone-gaps` | No direct equivalent; closest is running `/spec-audit-milestone` then manually creating phases via `/spec-phase add`. |
| `add-phase` / `insert-phase` / `remove-phase` | All consolidated under `/spec-phase` (subcommand-style: `/spec-phase add`, `/spec-phase remove`, etc.). |
| `new-workspace` / `remove-workspace` / `list-workspaces` | All consolidated under `/spec-workspace`. |

---

## Step 4 — Mode-specific output

### DRY-RUN (default)

Print a summary table. No file writes.

```
GSD → spectrum-os migration · DRY RUN
Project: <project-path>

  Safe rewrites (in .planning/ + CLAUDE.md):  N occurrences across M files
  Unresolved refs (in .planning/ + CLAUDE.md):  K occurrences across L files
  Out-of-zone refs (rest of repo, manual review):  P occurrences across Q files

Run with --apply to perform the rewrites.
Run with --report-only to generate a detailed report without rewriting.
```

### REPORT-ONLY

Write `<project-path>/migration-report.md` (see format in Step 5). No source files modified.

Print:

```
GSD → spectrum-os migration · REPORT ONLY
Project: <project-path>

  Report written: <project-path>/migration-report.md

  Safe rewrites planned:    N occurrences across M files (not applied)
  Unresolved refs:           K occurrences across L files
  Out-of-zone refs:          P occurrences across Q files (manual review)

Run with --apply to perform the safe rewrites.
```

### APPLY

For each safe-rewrite hit, use the `Edit` tool to perform the substitution. Track per-file counts.

After all rewrites complete, write `<project-path>/migration-report.md`.

Print:

```
GSD → spectrum-os migration · APPLIED
Project: <project-path>

  Safe rewrites performed:  N occurrences across M files
  Unresolved refs:          K occurrences across L files
  Out-of-zone refs:         P occurrences across Q files (manual review)

  Report written: <project-path>/migration-report.md

Review the report and resolve the K+P unresolved + out-of-zone refs manually.
```

---

## Step 5 — `migration-report.md` format

```markdown
# GSD → spectrum-os migration report

Generated: <ISO timestamp>
Project: <project-path>
Mode: <DRY-RUN | REPORT-ONLY | APPLIED>

---

## Summary

| Bucket | Count | Files | Auto-handled? |
|---|---|---|---|
| Safe rewrites | N | M | Yes (in `--apply` mode) |
| Unresolved refs | K | L | No — suggested action per ref |
| Out-of-zone refs | P | Q | No — manual review required |

---

## Safe rewrites

(Section header reads "Rewrites performed" in APPLY mode, "Rewrites planned" in DRY-RUN / REPORT-ONLY.)

| File | Line | Was | Now |
|---|---|---|---|
| `.planning/phases/01/PLAN.md` | 42 | `/gsd:execute-phase` | `/spec-execute-phase` |
| `.planning/STATE.md` | 7 | `gsd-tools state get` | `spec-tools state get` |
| ... | ... | ... | ... |

---

## Unresolved references (human review required)

Each entry shows the file:line, the matched text, and a suggested action.

### `.planning/STATE.md:23`

```
Next: run /gsd:do "deploy the canary"
```

- **GSD command:** `/gsd:do`
- **Suggested:** `/spec-quick` (urgent one-off, scoped smaller than a phase) or `/spec-fast` (trivial inline work)
- **Action:** Decide which fits the original intent and edit by hand.

(...repeat for each unresolved ref...)

---

## References outside the safe-rewrite zone

These references were found outside `.planning/` and `CLAUDE.md` — typically in `docs/`, `README.md`, source code, tests, or CI configs. They are **not** auto-rewritten because their meaning depends on context (a string in a code variable name vs. a command in a comment vs. an example in a doc). Review and edit each by hand.

### `docs/onboarding.md:42`

```
Use /gsd:plan-phase to start a new phase.
```

- **Found:** `/gsd:plan-phase`
- **Suggested:** `/spec-plan-phase` (1:1 spec equivalent)
- **Action:** Rewrite by hand if still relevant; delete if stale.

### `scripts/release.sh:8`

```
gsd-tools state get
```

- **Found:** `gsd-tools`
- **Suggested:** `spec-tools` (binary rename)
- **Action:** Update the script; verify spec-tools is on the runner's PATH.

(...repeat for each out-of-zone ref...)
```

---

## Step 6 — Done

Exit cleanly. No background tasks.

---

## Edge cases

- **Path with spaces:** quote `<project-path>` everywhere when shelling out.
- **Existing `migration-report.md`:** overwrite. Migrations are idempotent — running twice on the same project should produce the same report.
- **Binary files in `.planning/`** (rare, e.g. PDF specs): `grep -rnE` already skips binary matches by default with `-I` — add `-I` if grep version doesn't auto-skip.
- **Symlinks in `.planning/`:** follow them. spectrum-os doesn't use symlinks internally; if one exists, it's intentional.
- **`/gsd:<slug>` inside a code block:** rewrite anyway. Code blocks in `.planning/` markdown almost always show commands the user is meant to run, not literal strings to preserve.
- **`get-shit-done` as natural English** (very rare): would be incorrectly rewritten. Mitigation: the report shows every safe rewrite so the user can spot any false positive and revert manually.
