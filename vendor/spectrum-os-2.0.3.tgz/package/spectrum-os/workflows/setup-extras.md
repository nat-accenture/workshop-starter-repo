# Workflow: Setup extras (SPECTRUM SUPER POWERS)

Interactive installer for the seven capabilities in the spectrumOS extras catalog. The catalog source of truth is `~/.claude/spectrum-os/references/extras-catalog.md` (shipped with the framework install); this workflow reads its structured fields, drives the picker, runs the four pre-flight checks, and then executes each entry's `Install:` command block verbatim.

The workflow does not hardcode install commands or WebFetch upstream READMEs at install time. The catalog is the contract — to update an install, edit the catalog and bump `Last verified:`.

---

## Step 1 — Resolve mode

Parse `$ARGUMENTS`:
- `--all` → **SELECT-ALL** mode (every entry in the catalog)
- One or more bare digits in `1`–`7` → **SELECT-LISTED** mode (those capability numbers)
- Otherwise → **INTERACTIVE** mode (default)

---

## Step 2 — Load the catalog

Read the catalog from the installed framework data directory:

- Claude Code:  `~/.claude/spectrum-os/references/extras-catalog.md`
- Codex:        `~/.codex/spectrum-os/references/extras-catalog.md`
- Gemini:       `~/.gemini/spectrum-os/references/extras-catalog.md`
- Copilot:      `~/.copilot/spectrum-os/references/extras-catalog.md`

(Pick the path that matches the current runtime — the installer copies the same file into each runtime's framework data dir.)

If the file is missing at the expected location, exit with:

> Catalog not found at `<expected-path>`. spectrumOS extras cannot be installed without it. Reinstall the framework: from a spectrum-os source checkout, run `git pull && node bin/install.js`.

Parse each `## N · TIER — Capability` heading. For each capability, collect every `### Implementation:` block underneath. For each implementation, extract the structured fields:

| Field | Source line | Required? |
|---|---|---|
| `name` | the `### Implementation: <name>` heading | yes |
| `source_url` | `- **Source:** <url>` | yes |
| `license` | `- **License:** <SPDX or text>` | yes |
| `install_method` | `- **Install method:** <enum>` | yes — one of `npm-global`, `npx`, `claude-plugin-marketplace`, `mcp-config`, `homebrew`, `web-url`, `manual-copy` |
| `npm_package` | `- **npm package:** <name>` | only when `install_method` ∈ {`npm-global`, `npx`} |
| `last_verified` | `- **Last verified:** YYYY-MM-DD` | yes |
| `install_blocks` | every fenced code block under a `**Install …:**` heading | at least one |
| `verify_block` | the fenced code block under `**Verify:**` (if present) | optional |

---

## Step 3 — Render the picker (INTERACTIVE mode only)

Show the catalog as a numbered list (capability name + tier + personas). Use `AskUserQuestion` with `multiSelect: true` so the user can pick several entries in one round.

If SELECT-ALL or SELECT-LISTED, skip this step — the selection is already known.

---

## Step 4 — Resolve implementation choices

For each selected capability:

- If the capability has **one** implementation block: that's the choice.
- If the capability has **multiple** implementation blocks (e.g. #2 with three, #6 with two): ask the user via `AskUserQuestion` which variant fits their stack. Pull the *Notes* paragraph for each implementation into the question's `description` so the user sees the trade-offs.

Build a final list `selected[]` of `(capability_number, implementation_name)` tuples.

---

## Step 5 — Pre-flight checks per selection

For each `(capability, implementation)` in `selected[]`, run the four checks from the validation contract. **Dispatch off `install_method` — do not string-sniff the install prose.**

1. **Source URL resolves.** `curl -sI -o /dev/null -w "%{http_code}" <source_url>`. Accept 200 or 30x→200. Anything else → `✗`.
2. **Registry check.** Dispatch:
   - `install_method` ∈ {`npm-global`, `npx`}: `npm view <npm_package> name version 2>/dev/null`. Empty → `✗`.
   - `install_method` = `homebrew`: extract the formula name from the `Install` block (`brew install <formula>`) and run `brew info <formula> 2>/dev/null`. Skip with `n/a` if `brew` is not on PATH.
   - `install_method` ∈ {`claude-plugin-marketplace`, `mcp-config`, `web-url`, `manual-copy`}: no registry to probe → `n/a` (the URL check above is what gates this entry).
3. **License match.** If `license` is an SPDX identifier (e.g. `MIT`, `Apache-2.0`, `Elastic-2.0`), `WebFetch` the source URL and confirm the identifier appears. If `license` is `see source` or `depends on choice`, skip with `n/a`.
4. **Last-verified freshness.** `(today − last_verified) > 180 days` → `⚠`. Otherwise `✓`.

Render a summary table to stdout:

```
Selected installs — pre-flight summary

  #  Capability                          Impl              URL  reg  lic  fresh
  ─  ──────────────────────────────────  ────────────────  ───  ───  ───  ─────
  2  Version control & PR flow           gh                 ✓    ✓    ✓    ✓
  6  Browser automation                  Playwright         ✓    ✓    ✓    ✓
```

- Any `✗` is hard — that entry is removed from the install set and the failure reason printed.
- Any `⚠` is soft — the entry stays in the set. Ask the user via `AskUserQuestion` whether to proceed with warnings.

---

## Step 6 — Confirm before installing

Ask the user once, via `AskUserQuestion`, to confirm the final install set. Show the trimmed list (after Step 5 removals) and the order. Options:

- **Proceed** — run all installs in order.
- **Edit** — return to Step 3 (re-render picker).
- **Cancel** — exit without changes.

---

## Step 7 — Execute the install blocks

For each remaining `(capability, implementation)`:

1. Print a banner: `Installing #<N> · <Capability> · <Implementation>`.
2. Dispatch by `install_method`:
   - **`npm-global`, `npx`, `homebrew`** — execute every fenced `bash` block under `**Install …:**` (and `**Post-install auth:**` if present) line by line via `Bash`. On non-zero exit, mark the entry failed and surface stderr.
   - **`claude-plugin-marketplace`** — these are *Claude Code slash commands*, not shell commands. Do NOT shell out. Print the commands and instruct the user to paste them into the Claude Code prompt, e.g.:
     ```
     Run these in your Claude Code session, in order:
       /plugin marketplace add nextlevelbuilder/ui-ux-pro-max-skill
       /plugin install ui-ux-pro-max@ui-ux-pro-max-skill
     ```
     Mark the entry as `↪ user action required`.
   - **`mcp-config`** — read the JSON block from the install prose, merge it into `.claude/settings.json` under `mcpServers` (preserve existing entries; do not clobber). After write, instruct the user to restart Claude Code.
   - **`web-url`** — print the URL and a one-line "open this in a browser" hint. Mark as `✓ link`.
   - **`manual-copy`** — the install requires actions the agent cannot safely automate (downloading a bundle, then `cp -r` from a path the agent doesn't have). Print the *Install* block verbatim and instruct the user to follow it manually. Mark as `↪ user action required`.
3. If a `**Verify:**` block exists and the install method was directly executed (npm/npx/homebrew), run the verify block. Non-zero exit demotes the entry from `✓ installed` to `⚠ installed-but-verify-failed`.
4. Continue to the next entry — do not abort the whole run on a single failure.

---

## Step 8 — Final summary

Emit a per-entry result table:

```
Install results

  #  Implementation     Result                      Notes
  ─  ────────────────   ──────────────────────────  ────────────────────────────────────
  2  gh                 ✓ installed
  5  Excalidraw         ✓ link                      https://excalidraw.com
  6  Playwright         ✗ failed                    npm init playwright — exit 1
  3  ui-ux-pro-max      ↪ user action required      paste slash commands into prompt
```

For any entry that failed, print the captured stderr and a hint pointing at the catalog entry (line range in the installed `extras-catalog.md`) and the upstream source URL.

Exit code 0 if every directly-executed entry succeeded; otherwise exit code 1. `↪ user action required` entries do not affect the exit code (they're pending user input, not failures).
