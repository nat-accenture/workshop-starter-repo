# Workflow: Validate extras

Non-interactive sweep of every entry in the installed extras catalog (`~/.claude/spectrum-os/references/extras-catalog.md`, or the equivalent path under the active runtime's framework data dir). Runs the four pre-flight checks from the catalog's validation contract and emits a status table. Writes nothing to the user's system. Safe to schedule (quarterly cadence, pre-release).

The four checks are identical to Step 5 of the setup-extras workflow — `validate-extras` is the same logic run without the install action.

---

## Step 1 — Resolve mode

Parse `$ARGUMENTS`:
- `--json` → **JSON-OUT** mode
- One or more bare digits in `1`–`7` → restrict the sweep to those capability numbers
- Otherwise → **TABLE-OUT** mode covering every entry

---

## Step 2 — Load the catalog

Read the catalog from the installed framework data directory (same paths as the setup-extras workflow — pick whichever matches the active runtime):

- `~/.claude/spectrum-os/references/extras-catalog.md`
- `~/.codex/spectrum-os/references/extras-catalog.md`
- `~/.gemini/spectrum-os/references/extras-catalog.md`
- `~/.copilot/spectrum-os/references/extras-catalog.md`

If missing, exit with:

> Catalog not found at `<expected-path>`. Reinstall the framework: from a spectrum-os source checkout, run `git pull && node bin/install.js`.

Parse the same structured fields as setup-extras Step 2 — `source_url`, `license`, `install_method`, `npm_package` (when applicable), `last_verified`. **Dispatch off `install_method`; do not string-sniff the install prose.**

---

## Step 3 — Run the four checks per implementation

For every implementation in the (optionally filtered) catalog:

1. **Source URL resolves.** `curl -sI -o /dev/null -w "%{http_code}" <source_url>`. Accept 200 or 30x→200. Anything else → `✗`.
2. **Registry check.** Dispatch by `install_method`:
   - `npm-global` / `npx`: `npm view <npm_package> name version 2>/dev/null`. Empty → `✗`.
   - `homebrew`: extract the formula name from the `Install` block and run `brew info <formula> 2>/dev/null`. Skip with `n/a` if `brew` is not on PATH.
   - `claude-plugin-marketplace`, `mcp-config`, `web-url`, `manual-copy`: no registry to probe → `n/a` (the URL check above gates this entry).
3. **License match.** If `license` is an SPDX identifier (e.g. `MIT`, `Apache-2.0`, `Elastic-2.0`), `WebFetch` the source URL and confirm the identifier appears in the page text. Match → `✓`; discoverable but different → `✗`; not discoverable → `⚠`. Values like `see source` or `depends on choice` skip with `n/a`.
4. **Last-verified freshness.** `(today − last_verified) > 180 days` → `⚠`. Within 180 days → `✓`.

The implementation's overall status is the most severe of the four: `✗` > `⚠` > `✓`.

---

## Step 4 — Emit results

### TABLE-OUT (default)

```
spectrum-os extras — validation report (yyyy-mm-dd)

  #  Capability                          Impl              URL  reg  lic  fresh   status
  ─  ──────────────────────────────────  ────────────────  ───  ───  ───  ─────   ──────
  1  Context efficiency                  context-mode       ✓    ✓    ✓     ✓      ✓
  2  Version control & PR flow           gh                 ✓    ✓    ✓     ✓      ✓
  2  Version control & PR flow           glab               ✓    ✓    ✓     ✓      ✓
  2  Version control & PR flow           Bitbucket          ⚠    n/a  n/a    ✓      ⚠
  3  UI/UX design system generation      ui-ux-pro-max      ✓    ✓    ✓     ✓      ✓
  …

Legend  ✓ pass · ⚠ warning · ✗ fail · n/a not applicable
Summary  N implementations · X ✓ · Y ⚠ · Z ✗
```

After the table, list each `✗` (and optionally each `⚠`) with the specific reason — e.g. *"context-mode: source URL is the placeholder string — confirm canonical project URL"*.

### JSON-OUT (`--json`)

```json
{
  "generated_at": "2026-05-21T12:34:56Z",
  "catalog_path": "<runtime-data-dir>/spectrum-os/references/extras-catalog.md",
  "implementations": [
    {
      "capability_number": 1,
      "capability": "Context efficiency",
      "implementation": "context-mode",
      "tier": "CORE",
      "install_method": "claude-plugin-marketplace",
      "checks": {
        "source_url": { "status": "ok", "http_code": 200 },
        "registry":   { "status": "n/a", "detail": "claude-plugin-marketplace — no remote registry probe" },
        "license":    { "status": "ok", "spdx": "Elastic-2.0" },
        "freshness":  { "status": "ok", "days_since_verified": 0 }
      },
      "status": "ok"
    }
  ],
  "summary": { "ok": 0, "warn": 0, "fail": 0, "total": 0 }
}
```

---

## Step 5 — Exit code

- Any `✗` → exit code `1`
- Otherwise → exit code `0`

Warnings are surfaced but do not fail the run — they're meant to be triaged, not enforced.
